from django.db import models


class City(models.Model):
    geoname_id = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=200)
    country_code = models.CharField(max_length=3)
    population = models.IntegerField()
    timezone = models.CharField(max_length=200)
    priority = models.IntegerField(default=0)


class AlternateNameManager(models.Manager):
    def get_queryset(self):
        return (
            super()
            .get_queryset()
            .filter(language__in=("en", "ru"), is_historic=False, is_colloquial=False)
            .order_by("city_id", "language", "is_shortname", "-is_preferred")
            .distinct("city_id", "language")
        )


class AlternateName(models.Model):
    city = models.ForeignKey(
        City,
        on_delete=models.CASCADE,
        related_name="alternate_names",
    )
    name = models.CharField(max_length=200)
    language = models.CharField(max_length=10, blank=True, db_index=True)
    is_preferred = models.BooleanField(default=False, db_index=True)
    is_shortname = models.BooleanField(default=False, db_index=True)
    is_colloquial = models.BooleanField(default=False, db_index=True)
    is_historic = models.BooleanField(default=False, db_index=True)

    objects = AlternateNameManager()
