from rest_framework import serializers

from .models import AlternateName, City


class AlternateNameSerializer(serializers.ModelSerializer):
    class Meta:
        model = AlternateName
        fields = ("name", "language")


class CitySerializer(serializers.ModelSerializer):
    alternate_names = AlternateNameSerializer(many=True, read_only=True)

    class Meta:
        model = City
        fields = (
            "geoname_id",
            "name",
            "country_code",
            "population",
            "timezone",
            "alternate_names",
        )
