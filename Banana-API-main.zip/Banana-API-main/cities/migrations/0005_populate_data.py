import json
from django.db import migrations, models
import os
from cities.models import City


def insert_cities(apps, schema_editor):
    City = apps.get_model("cities", "City")
    os.system("tar -xzf cities/migrations/data/cities.tar.gz")
    with open("cities/migrations/data/cities.json") as file:
        cities = json.load(file)

    created_cities = City.objects.bulk_create([City(**entry) for entry in cities], batch_size=300)
    print(f"Created {len(created_cities)} cities")


def insert_alternate_names(apps, schema_editor):
    AlternateName = apps.get_model("cities", "AlternateName")
    os.system("tar -xzf cities/migrations/data/alternate_names.tar.gz")
    with open("cities/migrations/data/alternate_names.json") as file:
        names = json.load(file)

    created_alternate_names = AlternateName.objects.bulk_create(
        [AlternateName(**entry) for entry in names], batch_size=300
    )
    print(f"Created {len(created_alternate_names)} alternate names")


class Migration(migrations.Migration):
    dependencies = [
        ("cities", "0004_initial"),
    ]

    operations = [
        migrations.RunPython(insert_cities),
        migrations.RunPython(insert_alternate_names),
    ]
