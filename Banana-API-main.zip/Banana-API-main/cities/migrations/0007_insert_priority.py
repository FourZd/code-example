import json
from django.db import migrations
import os


def insert_priorities(apps, schema_editor):
    City = apps.get_model("cities", "City")
    os.system("tar -xzf cities/migrations/data/priorities.tar.gz")
    with open("cities/migrations/data/priorities.json") as file:
        priorities = json.load(file)
    city_priorities = {city["city_id"]: 999 - city["priority"] for city in priorities["data"]}
    updates = []

    for city_id, priority in city_priorities.items():
        updates.append(City(geoname_id=city_id, priority=priority))
    City.objects.bulk_update(updates, fields=["priority"])


class Migration(migrations.Migration):
    dependencies = [
        ("cities", "0006_city_priority"),
    ]

    operations = [
        migrations.RunPython(insert_priorities),
    ]
