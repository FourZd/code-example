from django.db.models import Count, Q
from drf_spectacular.utils import OpenApiParameter, extend_schema
from rest_framework.generics import ListAPIView
from rest_framework.pagination import LimitOffsetPagination
from rest_framework.permissions import IsAuthenticated

from .models import City
from .serializers import CitySerializer


@extend_schema(
    parameters=[
        OpenApiParameter(
            name="query",
            location=OpenApiParameter.QUERY,
            description="City query",
            required=False,
            type=str,
        ),
    ],
)
class CitiesView(ListAPIView):
    """List cities"""

    serializer_class = CitySerializer
    pagination_class = LimitOffsetPagination
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        lookup = self.request.query_params.get("query")
        queryset = City.objects
        if lookup:
            queryset = (
                queryset.annotate(
                    matching_alternate_names=Count(
                        "alternate_names", filter=Q(alternate_names__name__istartswith=lookup)
                    )
                )
                .filter(
                    Q(name__istartswith=lookup)
                    | Q(  # Search in the City model's name field from the first letter
                        matching_alternate_names__gt=0
                    )  # Check if there are matching alternate names
                )
                .prefetch_related("alternate_names")
            )
        return queryset.order_by("-priority", "-population")
