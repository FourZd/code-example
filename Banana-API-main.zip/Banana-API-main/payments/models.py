from django.conf import settings
from django.db import models


class PaymentStatus(models.TextChoices):
    PENDING = "0"
    SUCCEEDED = "1"
    CANCELED = "-1"


class Payment(models.Model):
    id = models.CharField(max_length=36, primary_key=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=3, default="RUB")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    status = models.CharField(choices=PaymentStatus.choices, max_length=20)
    session = models.ForeignKey("custom_auth.UserSession", null=True, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.user} - {self.amount}"

    class Meta:
        db_table = "payments"


class PostPayment(models.Model):
    post = models.ForeignKey("posts.Post", null=True, on_delete=models.CASCADE)
    payment = models.ForeignKey(Payment, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.post} - {self.payment}"

    class Meta:
        db_table = "post_payments"


class PeriodPostPayment(models.Model):
    period_start = models.DateTimeField()
    period_end = models.DateTimeField()
    payment = models.ForeignKey(Payment, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"posts-{self.period_start} - {self.period_end} - {self.payment}"

    class Meta:
        db_table = "period_payments"


class PeriodProfilePayment(models.Model):
    period_start = models.DateTimeField()
    period_end = models.DateTimeField()
    payment = models.ForeignKey(Payment, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"profiles-{self.period_start} - {self.period_end} - {self.payment}"
