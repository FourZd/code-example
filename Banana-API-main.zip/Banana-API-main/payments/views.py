from enum import StrEnum
from logging import getLogger

from django.conf import settings
from django.urls import reverse
from django.utils import timezone
from rest_framework.permissions import IsAuthenticated
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.views import APIView
from middleware.platform_middleware import Platform
from .models import Payment as PaymentModel
from .models import PaymentStatus, PeriodPostPayment, PeriodProfilePayment, PostPayment
from .serializers import (
    CreatePaymentResponseSerializer,
    PaymentStatusSerializer,
    PaymentPayloadSerializer,
    CreatePaymentRequestSerializer,
)
from custom_auth.models import UserSession
import hashlib
import requests
from email_validator import validate_email, EmailNotValidError
from drf_spectacular.utils import extend_schema
from django.http import QueryDict
import logging
from django.http import HttpResponse

logger = getLogger(__name__)
REDIS_CLIENT = settings.REDIS_NOTIFICATION_CLIENT


class PaymentTypes(StrEnum):
    POST = "Оплата объявления, 1 шт."
    PERIOD_POST = "Оплата объявления, неделя"
    PERIOD_PROFILE = "Оплата подписки"


class PaymentMetadataKeys(StrEnum):
    PAYMENT_TYPE = "payment_type"
    PAYMENT_DAYS = "payment_days"
    USER_ID = "user_id"


def process_notification(notification: QueryDict):
    notification = notification.dict()
    logger.info("Notification received: %s", notification)
    hashed_id = hashlib.md5(notification["orderID"].encode("utf-8")).hexdigest()
    if notification["action"] == "order_payed":
        payment_db = PaymentModel.objects.get(id=hashed_id)
        if payment_db.status == PaymentStatus.SUCCEEDED:
            logger.info("Payment already succeeded")
            return HttpResponse("OK")
        payment_db.status = PaymentStatus.SUCCEEDED
        payment_db.save()

        match notification["innerID"]:
            case "1":
                logger.info("Creating PostPayment")
                PostPayment.objects.create(payment=payment_db)

            case "2":
                logger.info("Creating post period payment")
                create_post_period_payment(payment_db)

            case "3":
                logger.info("Creating profile day payment")
                create_profile_day_payment(payment_db)

            case "4":
                logger.info("Creating profile week payment")
                create_profile_week_payment(payment_db)

            case _:
                logger.error("Unknown payment type: %s", notification["innerID"])
                return HttpResponse("OK")
        message = f"Оплата от пользователя.\nId пользователя: {payment_db.user.id}.\nСумма: {payment_db.amount}."
        REDIS_CLIENT.publish("payments", message)
    elif notification["action"] == "order_cancel":
        logger.info("Canceling payment")
        PaymentModel.objects.filter(id=hashed_id).update(status=PaymentStatus.CANCELED)

    return HttpResponse("OK")


def create_post_period_payment(payment: PaymentModel):
    period_start = post_period_paid_untill(payment.user_id) or timezone.now()  # type: ignore
    PeriodPostPayment.objects.create(
        payment=payment,
        period_start=period_start,
        period_end=period_start + timezone.timedelta(days=7),
    )
    logger.info("Post period payment created")


def post_period_paid_untill(user_id: int) -> timezone.datetime | None:
    now = timezone.now()
    latest_payment = (
        PeriodPostPayment.objects.filter(
            payment__user_id=user_id,
            payment__status=PaymentStatus.SUCCEEDED,
            period_end__gte=now,
        )
        .order_by("-period_start")
        .first()
    )

    return latest_payment.period_end if latest_payment else None


def create_profile_day_payment(payment: PaymentModel):
    period_start = profile_period_paid_untill(payment.user_id) or timezone.now()  # type: ignore
    PeriodProfilePayment.objects.create(
        payment=payment,
        period_start=period_start,
        period_end=period_start + timezone.timedelta(days=1),
    )
    logger.info("Profile day payment created")


def create_profile_week_payment(payment: PaymentModel):
    period_start = profile_period_paid_untill(payment.user_id) or timezone.now()  # type: ignore
    PeriodProfilePayment.objects.create(
        payment=payment,
        period_start=period_start,
        period_end=period_start + timezone.timedelta(days=7),
    )
    logger.info("Profile week payment created")


def profile_period_paid_untill(user_id: int) -> timezone.datetime | None:
    now = timezone.now()
    latest_payment = (
        PeriodProfilePayment.objects.filter(
            payment__user_id=user_id,
            payment__status=PaymentStatus.SUCCEEDED,
            period_end__gte=now,
        )
        .order_by("-period_start")
        .first()
    )
    return latest_payment.period_end if latest_payment else None


def get_order_info(order_id):
    action = "getOrderInfo"
    sign_str = f"{settings.PRIMEPAYMENTS_SECRET1_KEY}{action}{settings.PRIMEPAYMENTS_PROJECT_ID}{order_id}"
    sign = hashlib.md5(sign_str.encode("utf-8")).hexdigest()

    # Параметры запроса
    data = {
        "action": action,
        "project": settings.PRIMEPAYMENTS_PROJECT_ID,
        "orderID": order_id,
        "sign": sign,
    }

    response = requests.post("https://pay.primepayments.io/API/v2/", data=data).json()
    if response["status"] != "OK":
        return response

    # format binary date to datetime
    response["result"]["date_add"] = timezone.make_aware(
        timezone.datetime.fromtimestamp(int(response["result"]["date_add"])), timezone.utc
    )
    order_info = response["result"]
    return order_info


def create_payment_payload(
    amount: int, payment_type: PaymentTypes, email: str, innerID: int
) -> dict:
    action = "initPayment"

    # Подпись
    sign_str = f"{settings.PRIMEPAYMENTS_SECRET1_KEY}{action}{settings.PRIMEPAYMENTS_PROJECT_ID}{amount}{settings.PRIMEPAYMENTS_CURRENCY}{innerID}{email}"
    sign = hashlib.md5(sign_str.encode("utf-8")).hexdigest()

    data = {
        "action": action,
        "project": settings.PRIMEPAYMENTS_PROJECT_ID,
        "sum": amount,
        "currency": settings.PRIMEPAYMENTS_CURRENCY,
        "email": email,
        "sign": sign,
        "comment": payment_type,
        "innerID": innerID,
        "needFailNotice": 1,
    }
    logging.info(f"request body: {data}")
    response = requests.post("https://pay.primepayments.io/API/v2/", data=data)
    print(response.json())

    return response.json()


class PaymentCancelView(APIView):
    def post(self, request: Request):
        if not request.data:
            return Response(
                status=400,
                data={"error": "Empty data. Should be called by acquiring only"},
            )
        return process_notification(request.data)


class PaymentWebhookView(APIView):
    """Webhook."""

    def post(self, request: Request):
        if not request.data:
            return Response(
                status=400,
                data={"error": "Empty data. Should be called by acquiring only"},
            )
        return process_notification(request.data)


class CreatePostPaymentView(APIView):
    """Pay for a post."""

    serializer_class = CreatePaymentResponseSerializer
    permission_classes = [IsAuthenticated]
    # add email field requested for post

    def post(self, request: Request):
        try:
            email = settings.PAYMENT_EMAIL

            payment_response = create_payment_payload(
                amount=settings.POST_PAYMENT_PRICE,
                payment_type=PaymentTypes.POST,
                email=email,
                innerID=1,
            )
            payment_id = payment_response["order_id"]
            order_info = get_order_info(payment_id)
            payment_to_db(order_info, request.user)
        except Exception as e:
            logger.exception("Error creating payment", exc_info=True)
            return Response({"error": str(e)}, status=400)
        return Response(
            CreatePaymentResponseSerializer({"confirmation_url": payment_response["result"]}).data
        )


class CreatePeriodPostPaymentView(APIView):
    """Pay for unlimited posts for a week."""

    serializer_class = CreatePaymentResponseSerializer

    permission_classes = [IsAuthenticated]

    def post(self, request: Request):
        try:
            email = settings.PAYMENT_EMAIL

            payment_response = create_payment_payload(
                amount=settings.WEEK_POST_PAYMENT_PRICE,
                payment_type=PaymentTypes.PERIOD_POST,
                email=email,
                innerID=2,
            )
            payment_id = payment_response["order_id"]
            order_info = get_order_info(payment_id)
            payment_to_db(order_info, request.user)
        except Exception as e:
            return Response({"error": str(e)}, status=400)
        return Response(
            CreatePaymentResponseSerializer({"confirmation_url": payment_response["result"]}).data
        )


class CreateWeekProfilePaymentView(APIView):
    """Pay to send messages for a week."""

    serializer_class = CreatePaymentResponseSerializer

    permission_classes = [IsAuthenticated]

    def post(self, request: Request):
        try:
            email = settings.PAYMENT_EMAIL

            payment_response = create_payment_payload(
                amount=settings.WEEK_PROFILE_PAYMENT_PRICE,
                payment_type=PaymentTypes.PERIOD_PROFILE,
                email=email,
                innerID=4,
            )
            payment_id = payment_response["order_id"]
            order_info = get_order_info(payment_id)
            payment_to_db(order_info, request.user)
        except Exception as e:
            return Response({"error": str(e)}, status=400)
        return Response(
            CreatePaymentResponseSerializer({"confirmation_url": payment_response["result"]}).data
        )


class CreateDayProfilePaymentView(APIView):
    """Pay to send messages for a day."""

    serializer_class = CreatePaymentResponseSerializer

    permission_classes = [IsAuthenticated]

    def post(self, request: Request):
        try:
            email = settings.PAYMENT_EMAIL

            payment_response = create_payment_payload(
                amount=settings.DAY_PROFILE_PAYMENT_PRICE,
                payment_type=PaymentTypes.PERIOD_PROFILE,
                email=email,
                innerID=3,
            )
            payment_id = payment_response["order_id"]
            order_info = get_order_info(payment_id)
            payment_to_db(order_info, request.user)
        except Exception as e:
            return Response({"error": str(e)}, status=400)
        return Response(
            CreatePaymentResponseSerializer({"confirmation_url": payment_response["result"]}).data
        )


class PaymentStatusView(APIView):
    # Check which payments exists on user
    serializer_class = PaymentStatusSerializer
    permission_classes = [IsAuthenticated]

    def get(self, request: Request):
        post_payments_available = PostPayment.objects.filter(
            payment__user=request.user, payment__status=PaymentStatus.SUCCEEDED, post__isnull=True
        ).count()
        post_period_end = post_period_paid_untill(request.user.id)
        profile_period_end = profile_period_paid_untill(request.user.id)
        return Response(
            PaymentStatusSerializer(
                {
                    "post_payments_available": post_payments_available,
                    "post_period_paid": post_period_end is not None,
                    "post_period_end": post_period_end,
                    "profile_period_paid": profile_period_end is not None,
                    "profile_period_end": profile_period_end,
                }
            ).data
        )


def payment_to_db(payment: dict, user) -> PaymentModel:
    # Creates a new payment in database
    session = UserSession.objects.get(user=user, ended_at__gte=timezone.now())
    payment_db = PaymentModel(
        id=hashlib.md5(payment["order_id"].encode("utf-8")).hexdigest(),
        status=payment["pay_status"],
        amount=payment["sum"],  # type: ignore
        currency=settings.PRIMEPAYMENTS_CURRENCY,  # type: ignore
        user=user,
        session=session,
    )
    payment_db.save()
    return payment_db


def purchase_post(post: "posts.Post") -> bool:
    # Creates a new post if user payed for it
    period_payment = (
        PeriodPostPayment.objects.filter(
            payment__user=post.user, payment__status=PaymentStatus.SUCCEEDED
        )
        .order_by("-period_end")
        .first()
    )
    if period_payment and period_payment.period_end > timezone.now():
        post.save()
        return True
    post_payment = PostPayment.objects.filter(
        payment__user=post.user, payment__status=PaymentStatus.SUCCEEDED, post__isnull=True
    ).first()
    if post_payment:
        post.save()
        post_payment.post = post
        post_payment.save()
        return True
    return False
