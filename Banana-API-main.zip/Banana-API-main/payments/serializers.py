from rest_framework import serializers


class PaymentStatusSerializer(serializers.Serializer):
    post_payments_available = serializers.IntegerField()
    post_period_paid = serializers.BooleanField()
    post_period_end = serializers.DateTimeField(required=False)
    profile_period_paid = serializers.BooleanField()
    profile_period_end = serializers.DateTimeField(required=False)


class CreatePaymentResponseSerializer(serializers.Serializer):
    confirmation_url = serializers.URLField(read_only=True)


class CreatePaymentRequestSerializer(serializers.Serializer):
    email = serializers.EmailField()


class PaymentPayloadSerializer(serializers.Serializer):
    order_id = serializers.CharField()
    date_add = serializers.DateTimeField()
    sum = serializers.DecimalField(max_digits=10, decimal_places=2)
    payWay = serializers.IntegerField()
    innerID = serializers.IntegerField()
    pay_status = serializers.CharField()
