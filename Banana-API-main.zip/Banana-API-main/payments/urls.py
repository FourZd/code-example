from django.urls import path
from django.views.generic import TemplateView

from . import views

urlpatterns = [
    path("post/", views.CreatePostPaymentView.as_view(), name="create_post_payment"),
    path(
        "post/week/",
        views.CreatePeriodPostPaymentView.as_view(),
        name="create_post_period_payment",
    ),
    path(
        "profile/day/",
        views.CreateDayProfilePaymentView.as_view(),
        name="create_profile_day_payment",
    ),
    path(
        "profile/week/",
        views.CreateWeekProfilePaymentView.as_view(),
        name="create_profile_period_payment",
    ),
    path("webhook/", views.PaymentWebhookView.as_view(), name="webhook"),
    path("cancel/", views.PaymentCancelView.as_view(), name="cancel"),
    path("status/", views.PaymentStatusView.as_view(), name="status"),
    path(
        "close/",
        TemplateView.as_view(template_name="payments/close.html"),
        name="close",
    ),
]
