from django.contrib import admin

from .models import Payment, PeriodPostPayment, PostPayment, PeriodProfilePayment
from custom_auth.models import UserSession
from django.utils import timezone
from django.core.exceptions import MultipleObjectsReturned


class PaymentAdmin(admin.ModelAdmin):
    def save_model(self, request, obj, form, change):
        user = obj.user
        try:
            session, created = UserSession.objects.get_or_create(
                user=user,
                ended_at__gte=timezone.now(),
                defaults={
                    "started_at": timezone.now(),
                    "ended_at": timezone.now() + timezone.timedelta(minutes=10),
                },
            )
        except MultipleObjectsReturned:
            sessions = UserSession.objects.filter(
                user=request.user, ended_at__gte=timezone.now()
            ).order_by("ended_at")
            session = sessions.first()
            for extra_session in sessions[1:]:
                extra_session.delete()
            created = False
        if not created:
            session.ended_at = timezone.now() + timezone.timedelta(minutes=10)
            session.save()
        obj.session = session
        super().save_model(request, obj, form, change)

    list_display = (
        "id",
        "user",
        "amount",
        "currency",
        "created_at",
        "updated_at",
        "status",
    )
    list_filter = ("status", "currency", "created_at")
    search_fields = ("id", "user__username")
    readonly_fields = ("created_at", "updated_at")

    fieldsets = (
        (
            None,
            {
                "fields": (
                    "id",
                    "user",
                    "amount",
                    "currency",
                    "status",
                    "created_at",
                    "updated_at",
                )
            },
        ),
    )


admin.site.register(Payment, PaymentAdmin)


class PostPaymentAdmin(admin.ModelAdmin):
    list_display = ("post", "payment", "created_at", "updated_at")
    list_filter = ("created_at",)
    search_fields = ("post__name", "payment__id")
    readonly_fields = ("created_at", "updated_at")

    fieldsets = ((None, {"fields": ("post", "payment", "created_at", "updated_at")}),)


admin.site.register(PostPayment, PostPaymentAdmin)


class PeriodPaymentAdmin(admin.ModelAdmin):
    list_display = ("period_start", "period_end", "payment", "created_at", "updated_at")
    list_filter = ("created_at",)
    search_fields = ("payment__id",)
    readonly_fields = ("created_at", "updated_at")

    fieldsets = (
        (
            None,
            {
                "fields": (
                    "period_start",
                    "period_end",
                    "payment",
                    "created_at",
                    "updated_at",
                )
            },
        ),
    )


class PeriodProfilePaymentAdmin(admin.ModelAdmin):
    list_display = ("period_start", "period_end", "payment", "created_at", "updated_at")
    list_filter = ("created_at",)
    search_fields = ("payment__id",)
    readonly_fields = ("created_at", "updated_at")

    fieldsets = (
        (
            None,
            {
                "fields": (
                    "period_start",
                    "period_end",
                    "payment",
                    "created_at",
                    "updated_at",
                )
            },
        ),
    )


admin.site.register(PeriodProfilePayment, PeriodProfilePaymentAdmin)
admin.site.register(PeriodPostPayment, PeriodPaymentAdmin)
