from enum import Enum
from typing import Callable

from django.http import HttpRequest, HttpResponse


class Platform(Enum):
    IOS = "ios"
    ANDROID = "android"
    WEB = "web"

    @classmethod
    def _missing_(cls, value):
        return Platform.IOS


def platform_middleware(
    get_response: Callable[[HttpRequest], HttpResponse]
) -> Callable[[HttpRequest], HttpResponse]:
    def middleware(request: HttpRequest) -> HttpResponse:
        request.platform = Platform(request.headers.get("X-Platform"))
        request.is_on_moderation = request.platform == Platform.IOS
        response = get_response(request)
        return response

    return middleware
