from django.utils import timezone
from custom_auth.models import UserSession
from django.core.exceptions import MultipleObjectsReturned


class UserSessionMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        # Check if the user is authenticated
        if request.user.is_authenticated:
            # Update the last_online timestamp for the user
            try:
                session, created = UserSession.objects.get_or_create(
                    user=request.user,
                    ended_at__gte=timezone.now(),
                    defaults={
                        "started_at": timezone.now(),
                        "ended_at": timezone.now() + timezone.timedelta(minutes=10),
                    },
                )
            except MultipleObjectsReturned:
                sessions = UserSession.objects.filter(
                    user=request.user, ended_at__gte=timezone.now()
                ).order_by("ended_at")
                session = sessions.first()
                for extra_session in sessions[1:]:
                    extra_session.delete()
                created = False

            if not created:
                session.ended_at = timezone.now() + timezone.timedelta(minutes=10)
                session.save()
        return response
