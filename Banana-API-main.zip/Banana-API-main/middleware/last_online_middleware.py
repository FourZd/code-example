from typing import Callable

from django.contrib.auth import get_user_model
from django.http import HttpRequest, HttpResponse
from django.utils import timezone


class UpdateLastOnlineMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        # Check if the user is authenticated
        if request.user.is_authenticated:
            # Update the last_online timestamp for the user
            request.user.last_online = timezone.now()
            request.user.save()

        return response
