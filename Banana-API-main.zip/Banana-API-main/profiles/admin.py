from django.contrib import admin
from .models import Profile
from django import forms
from django.core.exceptions import ValidationError


class ProfileChangeForm(forms.ModelForm):
    deleted_at = forms.DateTimeField(
        required=False, widget=forms.DateTimeInput(attrs={"type": "datetime"})
    )
    hidden_at = forms.DateTimeField(
        required=False, widget=forms.DateTimeInput(attrs={"type": "datetime"})
    )

    def clean(self):
        cleaned_data = super().clean()
        telegram = cleaned_data.get("telegram")
        whatsapp = cleaned_data.get("whatsapp")

        if telegram and whatsapp:
            raise ValidationError("You can't set both Telegram and WhatsApp.")

    class Meta:
        model = Profile
        fields = "__all__"


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    form = ProfileChangeForm

    def get_queryset(self, request):
        return Profile.admin.all()

    list_display = (
        "user",
        "name",
        "city",
        "age",
        "height",
        "weight",
        "about",
        "telegram",
        "whatsapp",
        "hidden_at",
        "deleted_at",
    )
    fields = [
        "user",
        "name",
        "city",
        "age",
        "height",
        "weight",
        "about",
        "telegram",
        "whatsapp",
        "is_verified",
        "created_at",
        "updated_at",
        "hidden_at",
        "deleted_at",
    ]
    raw_id_fields = ["user", "city"]
    list_filter = ("user", "city", "created_at", "updated_at")
    search_fields = ("user", "name", "city")
    readonly_fields = ("created_at", "updated_at")
