from django.db.models import Q
from django.http import Http404
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django_filters.rest_framework import DjangoFilterBackend
from drf_spectacular.utils import OpenApiResponse, extend_schema, extend_schema_view
from rest_framework import status
from rest_framework.exceptions import PermissionDenied
from rest_framework.generics import ListCreateAPIView, RetrieveAPIView
from rest_framework.mixins import UpdateModelMixin
from rest_framework.pagination import LimitOffsetPagination
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from messaging.models import Message
from custom_auth.models import CustomUser

from .filters import ProfileFilter
from .models import Profile
from .serializers import (
    HideProfileSerializer,
    PrivateProfileSerializer,
    PublicProfileSerializer,
)


@extend_schema_view(
    list=extend_schema(responses=PublicProfileSerializer(many=True)),
    post=extend_schema(request=PrivateProfileSerializer),
)
class ListCreateProfileView(UpdateModelMixin, ListCreateAPIView):
    permission_classes = [IsAuthenticated]
    pagination_class = LimitOffsetPagination
    filter_backends = [DjangoFilterBackend]
    filterset_class = ProfileFilter

    def get_serializer_class(self):
        if self.request.method == "GET":
            return PublicProfileSerializer
        return PrivateProfileSerializer

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return Profile.objects.none()
        exclusions = (
            Q(user__gender=self.request.user.gender)
            | Q(user__in=self.request.user.blocked_users.all())
            | Q(user__in=self.request.user.blocked_by.all())
            | ~Q(user__profile__hidden_at=None)
        )
        return (
            Profile.objects.exclude(exclusions)
            .select_related("user", "city")
            .prefetch_related("user__photos", "city__alternate_names")
        )

    def perform_create(self, serializer: PrivateProfileSerializer):
        user = self.request.user
        existing_profile = Profile.objects.filter(user=user).first()
        if existing_profile:
            serializer.instance = existing_profile
        serializer.save(user=self.request.user)

    def get_object(self):
        return self.request.user.profile

    @extend_schema(request=PrivateProfileSerializer)
    def put(self, request, *args, **kwargs):
        """Update current user's profile."""
        return self.update(request, *args, **kwargs)

    @extend_schema(request=PrivateProfileSerializer)
    def patch(self, request, *args, **kwargs):
        """Partially update current user's profile."""
        return self.partial_update(request, *args, **kwargs)


# add multiple responses
@extend_schema_view(
    get=extend_schema(
        responses={
            status.HTTP_200_OK: OpenApiResponse(
                response=PublicProfileSerializer,
                description="Foreign profile. Doesn't contain private user data",
            ),
            "200-private": OpenApiResponse(
                response=PrivateProfileSerializer,
                description="User's profile with private data. Visible only to owner",
            ),
        }
    ),
)
class RetrieveProfileView(RetrieveAPIView):
    """Retrieve a user's profile by id."""

    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.kwargs["pk"] == self.request.user.id:
            return PrivateProfileSerializer
        return PublicProfileSerializer

    def get_object(self):
        user = get_object_or_404(CustomUser, id=self.kwargs["pk"])
        if user in self.request.user.blocked_users.all():
            raise PermissionDenied("Can't retrieve a profile you have blocked.")
        elif user in self.request.user.blocked_by.all():
            raise PermissionDenied("Can't retrieve a profile of a person who has blocked you.")
        try:
            profile = user.profile

            if (profile.hidden_at or profile.deleted_at) and user.id != self.request.user.id:
                raise Http404("No profile found matching the query.")

        except Profile.DoesNotExist:
            raise Http404("No profile found matching the query.")

        return profile


@extend_schema_view(
    delete=extend_schema(description="Delete current user's profile."),
)
class DeleteProfileView(APIView):
    """Delete current user's profile."""

    permission_classes = [IsAuthenticated]

    def delete(self, request, *args, **kwargs):
        """Delete current user's profile."""
        request.user.deleted_at = timezone.now()
        request.user.save()

        messages = Message.objects.filter(Q(sender=request.user) | Q(recipient=request.user))
        messages.update(deleted_at=timezone.now())

        try:
            profile = request.user.profile

            if not profile.deleted_at:
                profile.deleted_at = timezone.now()
                profile.save()
        except Profile.DoesNotExist:
            pass
        return Response(status=204)


@extend_schema(
    request=HideProfileSerializer, responses={status.HTTP_200_OK: HideProfileSerializer()}
)
class HideProfileView(APIView):
    """Hide current user's profile."""

    permission_classes = [IsAuthenticated]

    def put(self, request, *args, **kwargs):
        """Hide current user's profile."""
        profile = request.user.profile
        serializer = HideProfileSerializer(profile, data=request.data)
        if serializer.is_valid():
            toggle = timezone.now() if request.data["is_hidden"] else None
            profile.hidden_at = toggle
            profile.save()
            return Response(status=status.HTTP_200_OK, data=serializer.validated_data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
