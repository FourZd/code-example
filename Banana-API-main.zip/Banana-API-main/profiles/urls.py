from django.urls import path

from . import views

urlpatterns = [
    path("", views.ListCreateProfileView.as_view()),
    path("<int:pk>/", views.RetrieveProfileView.as_view()),
    path("delete/", views.DeleteProfileView.as_view()),
    path("hide/", views.HideProfileView.as_view()),
]
