from django.conf import settings
from django.db import models
from django.utils import timezone
from datetime import timedelta


class CustomProfileManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(deleted_at__isnull=True)


class AdminProfileManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().all()


class Profile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, primary_key=True
    )
    name = models.CharField(max_length=100)
    city = models.ForeignKey("cities.City", on_delete=models.CASCADE)
    age = models.IntegerField(db_index=True)
    height = models.IntegerField(db_index=True, null=True)
    weight = models.IntegerField(db_index=True, null=True)
    about = models.TextField()
    telegram = models.CharField(max_length=100, null=True, blank=True)
    whatsapp = models.CharField(max_length=100, null=True, blank=True)
    is_verified = models.BooleanField(default=False)
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)
    hidden_at = models.DateTimeField(null=True, db_index=True)
    deleted_at = models.DateTimeField(null=True, db_index=True)
    objects = CustomProfileManager()
    admin = AdminProfileManager()

    @property
    def is_recently_created(self):
        return self.created_at > timezone.now() - timedelta(days=7)
