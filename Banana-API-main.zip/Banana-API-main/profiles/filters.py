from django_filters import rest_framework as filters

from .models import Profile
from django.utils import timezone
from datetime import timedelta


class ProfileFilter(filters.FilterSet):
    city_geoname_id = filters.NumberFilter(field_name="city__geoname_id")
    is_recently_created = filters.BooleanFilter(method="filter_recently_created")
    is_online = filters.BooleanFilter(method="filter_is_online")

    def filter_recently_created(self, queryset, name, value):
        # TODO refactor it in models manager
        is_recently_created = timezone.now() - timedelta(days=7)
        if value:
            return queryset.filter(created_at__gte=is_recently_created)
        else:
            return queryset.filter(created_at__lt=is_recently_created)

    def filter_is_online(self, queryset, name, value):
        # TODO check for better DRY solution
        last_online = timezone.now() - timedelta(hours=5)
        if value:
            return queryset.filter(user__last_online__gte=last_online)
        else:
            return queryset.filter(user__last_online__lt=last_online)

    class Meta:
        model = Profile
        fields = {
            "age": ["gte", "lte"],
            "height": ["gte", "lte"],
            "weight": ["gte", "lte"],
        }
