from rest_framework import serializers

from cities.models import City
from cities.serializers import CitySerializer
from photos.serializers import PhotoSerializer

from .models import Profile


class PublicProfileSerializer(serializers.ModelSerializer):
    user_id = serializers.IntegerField(source="user.id", read_only=True)
    gender = serializers.IntegerField(source="user.gender", read_only=True)
    photos = PhotoSerializer(many=True, read_only=True, source="user.photos")
    city = CitySerializer(read_only=True)
    city_geoname_id = serializers.PrimaryKeyRelatedField(
        write_only=True,
        queryset=City.objects.all(),
        source="city",
    )
    is_online = serializers.BooleanField(source="user.is_online", read_only=True)

    class Meta:
        model = Profile
        fields = (
            "user_id",
            "name",
            "city",
            "city_geoname_id",
            "age",
            "height",
            "weight",
            "about",
            "is_verified",
            "photos",
            "gender",
            "is_online",
            "is_recently_created",
        )
        read_only_fields = (
            "user_id",
            "is_verified",
            "photos",
            "gender",
            "city",
            "is_online",
            "is_recently_created",
        )
        write_only_fields = ("city_geoname_id",)


class PrivateProfileSerializer(PublicProfileSerializer):
    telegram = serializers.CharField(allow_blank=False, allow_null=True, required=False)
    whatsapp = serializers.CharField(allow_blank=False, allow_null=True, required=False)

    class Meta(PublicProfileSerializer.Meta):
        fields = PublicProfileSerializer.Meta.fields + ("hidden_at", "whatsapp", "telegram")
        read_only_fields = PublicProfileSerializer.Meta.read_only_fields + ("hidden_at",)

    def validate(self, attrs):
        if attrs.get("whatsapp") and attrs.get("telegram"):
            raise serializers.ValidationError(
                {"error": "You cannot set both whatsapp and telegram"}
            )

        return super().validate(attrs)


class HideProfileSerializer(serializers.Serializer):
    is_hidden = serializers.BooleanField()
