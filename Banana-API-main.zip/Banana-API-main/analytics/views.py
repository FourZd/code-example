from django.shortcuts import render
from custom_auth.models import CustomUser, UserSession
from profiles.models import Profile
from payments.models import Payment
from django.db.models import Min
from django.db.models import (
    Q,
    F,
    ExpressionWrapper,
    fields,
    Avg,
    Count,
    Sum,
    Value,
    Case,
    When,
    IntegerField,
)
from django.utils import timezone
from itertools import chain
from django.db.models.functions import Coalesce
from collections import defaultdict
from payments.models import PostPayment, PeriodPostPayment, PeriodProfilePayment
from messaging.models import Message
from django.utils.timezone import make_aware


def format_timedelta(td):
    days = td.days
    hours, remainder = divmod(td.seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{days} дней, {hours} часов, {minutes} минут"


def main_analytics(request):
    return render(request, "analytics/main.html")


def math_analytics(date_from, date_to, date_requested):
    date_from = make_aware(date_from)
    date_to = make_aware(date_to)
    user_count = CustomUser.admin.filter(
        created_at__gte=date_from, created_at__lte=date_to
    ).count()

    women_count = CustomUser.admin.filter(
        gender=1, created_at__gte=date_from, created_at__lte=date_to
    ).count()
    men_count = CustomUser.admin.filter(
        gender=0, created_at__gte=date_from, created_at__lte=date_to
    ).count()

    profiles = Profile.admin.select_related("user").filter(
        created_at__gte=date_from, created_at__lte=date_to
    )
    profiles_count = profiles.count()
    males_profiles_count = profiles.filter(user__gender=0).count()
    females_profiles_count = profiles.filter(user__gender=1).count()
    chats = (
        Message.objects.filter(timestamp__gte=date_from, timestamp__lte=date_to)
        .annotate(
            lower_user=Case(
                When(sender__id__lt=F("recipient__id"), then="sender"),
                default="recipient",
                output_field=IntegerField(),
            ),
            higher_user=Case(
                When(sender__id__lt=F("recipient__id"), then="recipient"),
                default="sender",
                output_field=IntegerField(),
            ),
        )
        .values("lower_user", "higher_user")
        .annotate(count=Count("id"))
    )

    # Подсчет уникальных чатов
    chats_count = chats.count()

    deleted_users_count = CustomUser.admin.filter(
        deleted_at__isnull=False, deleted_at__gte=date_from, deleted_at__lte=date_to
    ).count()

    paying_users_count = (
        Payment.objects.filter(updated_at__gte=date_from, updated_at__lte=date_to, status=1)
        .values("user_id")
        .distinct()
        .count()
    )

    payments_count = Payment.objects.filter(
        updated_at__gte=date_from, updated_at__lte=date_to, status=1
    ).count()

    if paying_users_count == 0 or payments_count == 0 or user_count == 0:
        avg_payments_per_user = 0
    else:
        avg_payments_per_user = payments_count / user_count
        avg_payments_per_user = round(avg_payments_per_user, 3)

    total_profit = Payment.objects.filter(
        updated_at__gte=date_from, updated_at__lte=date_to, status=1
    ).aggregate(total_profit=Sum("amount"))["total_profit"]

    if total_profit is None:
        total_profit = 0
    messages_count = Message.objects.filter(
        timestamp__gte=date_from, timestamp__lte=date_to
    ).count()
    if date_requested is True:
        active_users_count = CustomUser.objects.filter(
            last_online__gte=date_from, last_online__lte=date_to
        ).count()
    else:
        active_users_count = CustomUser.objects.filter(
            last_online__gte=timezone.now() - timezone.timedelta(days=7)
        ).count()

    if total_profit == 0 or user_count == 0:
        avg_total_payments = 0
    else:
        avg_total_payments = total_profit / user_count
        avg_total_payments = round(avg_total_payments, 2)

    queryset = (
        Payment.objects.select_related("user")
        .filter(updated_at__gte=date_from, updated_at__lte=date_to, status=1)
        .values("user__created_at")
        .annotate(min_created_at=Min("created_at"))
    )
    durations = queryset.annotate(
        duration=ExpressionWrapper(
            F("min_created_at") - F("user__created_at"), output_field=fields.DurationField()
        )
    )
    raw_delta = durations.aggregate(average_duration=Avg("duration"))["average_duration"]
    if raw_delta is None:
        raw_delta = timezone.timedelta(0)
    avg_time_between_reg_and_payment = format_timedelta(raw_delta)

    sessions_count = UserSession.objects.filter(
        started_at__gte=date_from, started_at__lte=date_to
    ).count()
    if sessions_count == 0 or user_count == 0:
        avg_sessions = 0
    else:
        avg_sessions = sessions_count / user_count
        avg_sessions = round(avg_sessions, 2)

    if total_profit == 0 or sessions_count == 0:
        avg_payments_per_session = 0
    else:
        avg_payments_per_session = total_profit / sessions_count
        avg_payments_per_session = round(avg_payments_per_session, 2)

    post_payments_count = PostPayment.objects.filter(
        created_at__gte=date_from, created_at__lte=date_to
    ).count()
    period_post_payments_count = PeriodPostPayment.objects.filter(
        created_at__gte=date_from,
        created_at__lte=date_to,
        period_start=ExpressionWrapper(
            F("period_end") - timezone.timedelta(days=7), output_field=fields.DateTimeField()
        ),
    ).count()
    one_day_profiles_payments_count = PeriodProfilePayment.objects.filter(
        created_at__gte=date_from,
        created_at__lte=date_to,
        period_start=ExpressionWrapper(
            F("period_end") - timezone.timedelta(hours=24), output_field=fields.DateTimeField()
        ),
    ).count()
    one_week_profiles_payments_count = PeriodProfilePayment.objects.filter(
        created_at__gte=date_from,
        created_at__lte=date_to,
        period_start=ExpressionWrapper(
            F("period_end") - timezone.timedelta(days=7), output_field=fields.DateTimeField()
        ),
    ).count()

    return {
        "Количество зарегистрировавшихся пользователей": user_count,
        "Количество зарегистрировавшихся женщин": women_count,
        "Количество зарегистрировавшихся мужчин": men_count,
        "Количество созданных профилей": profiles_count,
        "Общая прибыль": total_profit,
        "Количество удаленных пользователей": deleted_users_count,
        "Количество платящих пользователей": paying_users_count,
        "Среднее время между регистрацией и первым платежом": avg_time_between_reg_and_payment,
        "Средний платеж на пользователя": avg_payments_per_user,
        "Количество активных пользователей": active_users_count,
        "Средний суммарный платеж на пользователя": avg_total_payments,
        "Среднее количество сессий": avg_sessions,
        "Среднее количество платежей на сессию": avg_payments_per_session,
        "Количество платежей за посты": post_payments_count,
        "Количество платежей за период постов": period_post_payments_count,
        "Количество платежей профилей на 1 день": one_day_profiles_payments_count,
        "Количество платежей профилей на 7 дней": one_week_profiles_payments_count,
        "Количество чатов": chats_count,
        "Количество мужских профилей": males_profiles_count,
        "Количество женских профилей": females_profiles_count,
        "Количество сообщений": messages_count,
    }


def average_analytics(request):
    per_day_dict = {}
    date_requested = False

    date_from = request.GET.get("dateFrom")
    date_to = request.GET.get("dateTo")

    if date_from:
        date_requested = True
        date_from = timezone.datetime.strptime(date_from, "%Y-%m-%d")
    else:
        date_from = timezone.datetime(2023, 4, 1)

    if date_to:
        date_to = timezone.datetime.strptime(date_to, "%Y-%m-%d") + timezone.timedelta(
            hours=23, minutes=59, seconds=59, microseconds=999999
        )
    else:
        date_to = timezone.datetime.now()

    current_date = date_from
    while current_date <= date_to:
        current_date_to = current_date + timezone.timedelta(
            hours=23, minutes=59, seconds=59, microseconds=999999
        )
        per_day_dict[timezone.datetime.strftime(current_date, "%d/%m/%Y")] = math_analytics(
            current_date, current_date_to, date_requested
        )
        current_date += timezone.timedelta(days=1)
    data = math_analytics(date_from, date_to, date_requested)
    print(per_day_dict)
    parameter_names = list(next(iter(per_day_dict.values())).keys())
    return render(
        request,
        "analytics/average.html",
        {
            "user_count": data.get("Количество зарегистрировавшихся пользователей"),
            "women_count": data.get("Количество зарегистрировавшихся женщин"),
            "men_count": data.get("Количество зарегистрировавшихся мужчин"),
            "profiles_count": data.get("Количество созданных профилей"),
            "total_profit": data.get("Общая прибыль"),
            "deleted_users_count": data.get("Количество удаленных пользователей"),
            "paying_users_count": data.get("Количество платящих пользователей"),
            "avg_time_between_reg_and_payment": data.get(
                "Среднее время между регистрацией и первым платежом"
            ),
            "avg_payments_per_user": data.get("Среднее количество платежей на пользователя"),
            "active_users_count": data.get("Количество активных пользователей"),
            "avg_total_payments": data.get("Средний суммарный платеж на пользователя"),
            "avg_sessions": data.get("Среднее количество сессий"),
            "avg_payments_per_session": data.get("Среднее количество платежей на сессию"),
            "post_payments_count": data.get("Количество платежей за посты"),
            "period_post_payments_count": data.get("Количество платежей за период постов"),
            "one_day_profiles_payments_count": data.get("Количество платежей профилей на 1 день"),
            "one_week_profiles_payments_count": data.get("Количество платежей профилей на 7 дней"),
            "chat_count": data.get("Количество чатов"),
            "male_profiles_count": data.get("Количество мужских профилей"),
            "female_profiles_count": data.get("Количество женских профилей"),
            "messages_count": data.get("Количество сообщений"),
            "per_day_dict": per_day_dict,
            "parameter_names": parameter_names,
        },
    )


def users_analytics(request):
    session_durations = (
        UserSession.objects.values("user_id")
        .annotate(
            total_duration=Sum(
                ExpressionWrapper(
                    F("ended_at") - F("started_at"), output_field=fields.DurationField()
                )
            ),
            session_count=Count("id"),
        )
        .annotate(
            average_session_duration=ExpressionWrapper(
                F("total_duration") / F("session_count"), output_field=fields.DurationField()
            )
        )
        .order_by("user_id")
    )
    queryset = (
        Payment.objects.select_related("user")
        .values("user__created_at", "user_id")
        .annotate(min_created_at=Min("created_at"))
    )
    registration_durations = (
        queryset.values("user_id")
        .annotate(
            time_between_reg_and_payment=Coalesce(
                ExpressionWrapper(
                    F("min_created_at") - F("user__created_at"),
                    output_field=fields.DurationField(),
                ),
                Value(None),  # Replace with None if the expression is None
            )
        )
        .order_by("user_id")
    )
    users = (
        CustomUser.admin.values("username", "created_at", "last_online")
        .annotate(
            total_payment_amount=Sum("payment__amount"),
            total_sessions_count=Count("usersession"),
            total_payments_count=Count("payment"),
        )
        .annotate(user_id=F("id"))
        .order_by("id")
    )
    merged_dict = defaultdict(dict)
    for item in users:
        merged_dict[item["user_id"]].update(item)

    # Merge dictionaries from list2
    for item in registration_durations:
        merged_dict[item["user_id"]].update(item)

    # Merge dictionaries from list3
    for item in session_durations:
        merged_dict[item["user_id"]].update(item)

    result_list = list(merged_dict.values())
    return render(request, "analytics/users.html", context={"data": result_list})
