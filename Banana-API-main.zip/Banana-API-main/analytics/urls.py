from django.urls import path

from . import views

urlpatterns = [
    path("", views.main_analytics),
    path("average/", views.average_analytics),
    path("users/", views.users_analytics),
]
