document.addEventListener('DOMContentLoaded', function() {
    // Получаем элементы интерфейса
    var applyButton = document.getElementById('applyDateFilter');
    var dateFromInput = document.getElementById('dateFrom');
    var dateToInput = document.getElementById('dateTo');

    // Обработчик события для кнопки применения фильтра
    applyButton.addEventListener('click', function() {
        // Считываем значения дат
        var dateFrom = dateFromInput.value;
        var dateTo = dateToInput.value;

        // Проверяем, выбраны ли обе даты
        if (dateFrom && dateTo) {
            // Формируем новый URL с query параметрами
            var newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
            newUrl += `?dateFrom=${encodeURIComponent(dateFrom)}&dateTo=${encodeURIComponent(dateTo)}`;

            // Перенаправляем браузер на новый URL
            window.location.href = newUrl;
        } else {
            alert('Пожалуйста, выберите обе даты.');
        }
    });
});