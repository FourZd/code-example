from django.contrib import admin
from custom_auth.models import CustomUser


class CustomAdmin(admin.AdminSite):
    site_header = "Custom Admin Site"

    def index(self, request, extra_context=None):
        # Calculate the user count
        user_count = CustomUser.objects.count()

        # Create a dictionary with the user count
        user_data = {
            "user_count": user_count,
        }

        # Pass the user_data to the admin index template
        extra_context = extra_context or {}
        extra_context["user_data"] = user_data

        return super().index(request, extra_context)


admin.register(CustomUser, CustomAdmin)
