from django import template

register = template.Library()


@register.filter
def get_nested_value(dict_, key):
    return dict_.get(key, {})
