#!/bin/bash

# This is ran automatically when the S3 docker container starts, due to where we mount it
#  so on startup of the S3 container, it will ensure that this bucket we use exists
awslocal s3 mb s3://development
