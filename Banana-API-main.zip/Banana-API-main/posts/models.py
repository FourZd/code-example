from django.conf import settings
from django.db import models


# Create your models here.
class Post(models.Model):
    name = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    age = models.PositiveSmallIntegerField()
    text = models.TextField()
    telegram = models.CharField(max_length=100, null=True, blank=True)
    whatsapp = models.CharField(max_length=100, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    is_fake = models.BooleanField(default=False, db_index=True)
    is_demo = models.BooleanField(default=False, db_index=True)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="posts"
    )

    def __str__(self):
        return self.name + ": " + self.text[:75] + (self.text[75:] and "...")

    class Meta:
        ordering = ["-created_at"]
