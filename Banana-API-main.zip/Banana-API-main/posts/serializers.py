from rest_framework import serializers

from custom_auth.serializers import UserSerializer

from .models import Post


class PostSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = Post
        fields = (
            "id",
            "name",
            "city",
            "age",
            "text",
            "telegram",
            "whatsapp",
            "created_at",
            "user",
        )
