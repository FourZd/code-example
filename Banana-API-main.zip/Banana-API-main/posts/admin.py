from django.contrib import admin

from .models import Post


class PostAdmin(admin.ModelAdmin):
    list_display = ("name", "city", "age", "created_at", "is_fake", "is_demo", "user")
    list_filter = ("city", "is_fake", "is_demo", "created_at")
    search_fields = ("name", "city", "text")
    readonly_fields = ("created_at",)

    fieldsets = (
        (
            None,
            {
                "fields": (
                    "name",
                    "city",
                    "age",
                    "text",
                    "created_at",
                    "is_fake",
                    "is_demo",
                    "user",
                )
            },
        ),
        ("Contact", {"fields": ("telegram", "whatsapp")}),
    )


admin.site.register(Post, PostAdmin)
