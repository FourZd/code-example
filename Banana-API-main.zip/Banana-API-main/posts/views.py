from datetime import timedelta

from django.utils.timezone import now
from rest_framework.exceptions import APIException
from rest_framework.generics import ListCreateAPIView
from rest_framework.pagination import LimitOffsetPagination
from rest_framework.response import Response

from custom_auth.permissions import IsMaleOrReadOnly
from payments.views import purchase_post
from .models import Post
from .serializers import PostSerializer


class PaymentRequired(APIException):
    status_code = 402
    default_detail = "Payment required."
    default_code = "payment_required"


class TooSoon(APIException):
    status_code = 418
    default_detail = "You can only create posts once an hour."
    default_code = "too_soon"


class PostsListCreateView(ListCreateAPIView):
    """GET obtains paginated list of posts, POST creates a new post."""

    permission_classes = [IsMaleOrReadOnly]
    model = Post
    serializer_class = PostSerializer
    pagination_class = LimitOffsetPagination

    def get_queryset(self):
        return Post.objects.filter(
            is_fake=self.request.user.is_fake,
            created_at__gte=now() - timedelta(hours=2),
        ).order_by("-created_at")

    def perform_create(self, serializer):
        post = Post(
            **{
                **serializer.validated_data,
                "is_fake": self.request.user.is_fake,
            }
        )
        post.user = self.request.user

        if post.is_fake:
            post.save()
            return
        last_post = Post.objects.filter(user=self.request.user).order_by("-created_at").first()
        if last_post and last_post.created_at > now() - timedelta(hours=1):
            raise TooSoon()
        is_purchased = purchase_post(post)
        if not is_purchased:
            raise PaymentRequired()

    def handle_exception(self, exc):
        if isinstance(exc, (PaymentRequired, TooSoon)):
            return Response({"detail": exc.detail}, status=exc.status_code)
        return super().handle_exception(exc)
