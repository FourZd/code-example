from datetime import timedelta
from logging import getLogger
from random import random
from time import sleep

import requests
from celery import shared_task
from django.db.models import F, Q
from django.utils import timezone

from .models import Post

logger = getLogger(__name__)
groups = [
    {"id": "120363023765599177@g.us", "name": "F O R B E S [Ultima]", "type": "group"},
    {
        "id": "120363025232460906@g.us",
        "name": "F O R B E S [Production]",
        "type": "group",
    },
    {"id": "120363027893411392@g.us", "name": "Мои группы, Москва💚", "type": "group"},
    {
        "id": "120363027894624096@g.us",
        "name": "F O R B E S[BALENCIAGA]➕➕",
        "type": "group",
    },
    {
        "id": "120363028563790089@g.us",
        "name": "F O R B E S [BALENCIAGA]",
        "type": "group",
    },
    {"id": "120363028738498649@g.us", "name": "F O R B E S[MODELS]", "type": "group"},
    {
        "id": "120363029829727361@g.us",
        "name": "F O R B E S[BALENCIAGA]➕",
        "type": "group",
    },
    {"id": "120363030426967930@g.us", "name": "F O R B E S [ TOP ]", "type": "group"},
    {
        "id": "120363034538114117@g.us",
        "name": "F O R B E S [MERCEDES]",
        "type": "group",
    },
    {"id": "120363037426518503@g.us", "name": "F O R B E S [BMW]", "type": "group"},
    {
        "id": "120363039514567539@g.us",
        "name": "F O R B E S [Jo malone",
        "type": "group",
    },
    {"id": "120363039727760403@g.us", "name": "F O R B E S [RITZ]", "type": "group"},
    {"id": "120363040834300291@g.us", "name": "F O R B E S [ Lotte ]", "type": "group"},
    {"id": "120363040862867214@g.us", "name": "F O R B E S [Legend]", "type": "group"},
    {"id": "120363042863376644@g.us", "name": "F O R B E S [MASSON]", "type": "group"},
    {"id": "120363044183685821@g.us", "name": "F O R B E S [Times]", "type": "group"},
    {"id": "120363044419546686@g.us", "name": "F O R B E S [ROLEX]", "type": "group"},
    {"id": "120363044912174272@g.us", "name": "F O R B E S [RUSSIA]", "type": "group"},
    {
        "id": "120363045321215558@g.us",
        "name": "F O R B E S [BALENCIAGA]1️⃣",
        "type": "group",
    },
    {"id": "120363046617704788@g.us", "name": "F O R B E S [ ЦУМ ]", "type": "group"},
    {
        "id": "120363152311093102@g.us",
        "name": "ATOLIN| предложения от мужчин",
        "type": "group",
    },
    {
        "id": "77761753137-1536388833@g.us",
        "name": "[F O R B E S] POLITICO",
        "type": "group",
    },
    {
        "id": "79507167216-1500029619@g.us",
        "name": "[F O R B E S] ELLE",
        "type": "group",
    },
    {
        "id": "79529953062-1620484653@g.us",
        "name": "НАСТОЯЩИЕ МАСТЕРА 1",
        "type": "group",
    },
    {
        "id": "79529953062-1621255775@g.us",
        "name": "НАСТОЯЩИЕ МАСТЕРА - 2",
        "type": "group",
    },
    {
        "id": "79529953062-1622447999@g.us",
        "name": "НАСТОЯЩИЕ МАСТЕРА - 3",
        "type": "group",
    },
    {
        "id": "79529953062-1624286604@g.us",
        "name": "НАСТОЯЩИЕ МАСТЕРА - 4",
        "type": "group",
    },
    {
        "id": "79529953062-1632053487@g.us",
        "name": "F O R B E S [world] # 1",
        "type": "group",
    },
    {
        "id": "79529953062-1632053594@g.us",
        "name": "F O R B E S [world] # 2",
        "type": "group",
    },
    {
        "id": "79529953062-1632053632@g.us",
        "name": "F O R B E S [world] # 3",
        "type": "group",
    },
    {
        "id": "79529953062-1632053694@g.us",
        "name": "F O R B E S [world] # 4",
        "type": "group",
    },
    {
        "id": "79529953062-1632053760@g.us",
        "name": "F O R B E S [world] # 5",
        "type": "group",
    },
    {
        "id": "79529953062-1633435885@g.us",
        "name": "F O R B E S [Life]",
        "type": "group",
    },
    {
        "id": "79692810100-1508833981@g.us",
        "name": "[F O R B E S ] VOGUE",
        "type": "group",
    },
    {
        "id": "79999754656-1519498607@g.us",
        "name": "F O R B E S [ G I F T ]",
        "type": "group",
    },
    {
        "id": "79999754656-1519573135@g.us",
        "name": "F O R B E S [ МАТРЕШКА]",
        "type": "group",
    },
]


@shared_task
def delete_old_posts():
    # n_deleted, _ = Post.objects.filter(
    #     is_fake=False, is_demo=False, created_at__lt=timezone.now() - timedelta(hours=2)
    # ).delete()
    n_updated = Post.objects.filter(
        Q(is_fake=True) | Q(is_demo=True),
        created_at__lt=timezone.now() - timedelta(hours=1),
    ).update(created_at=F("created_at") + timedelta(hours=1))
    return {"updated": n_updated}


@shared_task()
def handle_notifications(post_id: int):
    post = Post.objects.get(id=post_id)

    contact_str = ""
    if post.telegram:
        contact_str += f"https://t.me/{post.telegram} "
    if post.whatsapp:
        contact_str += f"https://wa.me/{post.whatsapp[1:]}"

    whatsapp_message = f"""*Это прямое предложения от мужчины с сервиса знакомств HelloBanana.*

Город {post.city}
{post.age} лет
{post.name}

{post.text}

Для связи с мужчиной: {contact_str}

*Все предложения смотрите в приложении знакомств HelloBanana*

https://hellobanana.io"""
    for group in groups:
        logger.info(f"Sending to {group['name']}")
        retries = 0
        while retries < 3:
            response = requests.post(
                "http://wa-bot:3000/send-message",
                json={
                    "jid": group["id"],
                    "message": whatsapp_message,
                },
                auth=("wa-sender", "iovdh98HUH0_dsaf"),
            )
            logger.info(f"Response: {response.status_code} {response.text}")
            logger.info(f"Sent to {group['name']}")
            # Delay between messages
            sleep(1 + random() * 1.5)
            retries += 1
            if response.status_code == 200:
                break

    return {"sent": True}
