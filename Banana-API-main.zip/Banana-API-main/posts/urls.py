from django.urls import path

from .views import PostsListCreateView

urlpatterns = [path("", PostsListCreateView.as_view(), name="posts_list_create")]
