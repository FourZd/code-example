from rest_framework import serializers
from .models import Message, MessageType
from profiles.models import Profile
from custom_auth.models import CustomUser
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from photos.models import Photo
from photos.serializers import PhotoSerializer
from payments.models import PeriodProfilePayment
from django.utils import timezone
from sorl.thumbnail import get_thumbnail
from drf_spectacular.types import OpenApiTypes
from drf_spectacular.utils import extend_schema_field
from payments.views import PaymentStatus
from django.core.exceptions import MultipleObjectsReturned


class MessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = Message
        fields = [
            "id",
            "sender",
            "recipient",
            "content",
            "image",
            "type",
            "timestamp",
            "read_at",
            "contact_type",
            "contact_value",
        ]
        read_only_fields = ("read_at", "sender", "contact_type", "contact_value")

    def validate(self, attrs):
        recipient = attrs.get("recipient")
        sender = self.context["request"].user
        content = attrs.get("content")
        image = attrs.get("image")
        type = attrs.get("type")

        if recipient == sender:
            raise serializers.ValidationError({"error": "You cannot send a message to yourself"})
        elif sender.gender == recipient.gender:
            raise serializers.ValidationError(
                {"error": "You cannot send a message to same gender"}
            )

        elif not content and not image and type == "msg":  # Check if message is empty
            raise serializers.ValidationError({"error": "Message content or image is required"})
        elif type == "shared_contacts":
            if content or image:
                raise serializers.ValidationError(
                    {"error": "You cannot send a message or image with shared contacts"}
                )
            try:
                # Check if the sender's profile has empty telegram and whatsapp
                Profile.objects.get(user=sender, telegram=None, whatsapp=None)
                raise serializers.ValidationError({"error": "You cannot share empty contacts"})
            except Profile.DoesNotExist:
                pass  # Proceed if the profile with empty contacts is not found
        if sender.is_male():
            try:
                PeriodProfilePayment.objects.get(
                    payment__user=sender,
                    period_end__gte=timezone.now(),
                    payment__status=PaymentStatus.SUCCEEDED,
                )
            except PeriodProfilePayment.DoesNotExist:
                raise serializers.ValidationError({"error": "You need to buy subscription first"})
            except MultipleObjectsReturned:
                pass
        try:  # TODO check if it works
            sender.blocked_users.get(id=recipient.id)
            raise serializers.ValidationError({"error": "Can't send message to blocked user"})
        except CustomUser.DoesNotExist:
            pass

        try:  # TODO check if it works
            sender.blocked_by.get(id=recipient.id)
            raise serializers.ValidationError({"error": "You are blocked by this user"})
        except CustomUser.DoesNotExist:
            pass

        try:
            Profile.objects.get(user=recipient)
        except Profile.DoesNotExist:
            raise serializers.ValidationError({"error": "Recipient profile does not exist"})
        try:
            Profile.objects.get(user=sender)
        except Profile.DoesNotExist:
            raise serializers.ValidationError({"error": "Sender profile does not exist"})

        return super().validate(attrs)


class ContactsSerializer(serializers.Serializer):
    user = serializers.IntegerField()
    whatsapp = serializers.CharField()
    telegram = serializers.CharField()

    class Meta:
        fields = ["user", "whatsapp", "telegram"]
        read_only_fields = ("user", "whatsapp", "telegram")


class LastMessageSerializer(serializers.Serializer):
    sender = serializers.IntegerField()
    content = serializers.CharField(allow_blank=True, allow_null=True)
    image = serializers.ImageField(required=False, allow_null=True)
    timestamp = serializers.DateTimeField()
    type = serializers.CharField()
    image_thumbnails = serializers.SerializerMethodField()

    # TODO DRY this
    @extend_schema_field(OpenApiTypes.OBJECT)
    def get_image_thumbnails(self, obj):
        image = obj.get("image")
        if image:
            return {
                "235х189": get_thumbnail(image, "235x189", crop="center", quality=99).url,
                "106х106": get_thumbnail(image, "106x106", crop="center", quality=99).url,
                "414х514": get_thumbnail(image, "414x514", crop="center", quality=99).url,
                "45х45": get_thumbnail(image, "45x45", crop="center", quality=99).url,
            }
        return None

    class Meta:
        fields = ["sender", "content", "image", "timestamp", "type"]
        read_only_fields = ("sender", "content", "image", "timestamp", "type", "image_thumbnails")


class ChatSerializer(serializers.Serializer):
    photo = serializers.ImageField(required=False, allow_null=True)
    chatmate = serializers.CharField()
    chatmate_id = serializers.IntegerField()
    last_message = LastMessageSerializer()
    unread_messages = serializers.IntegerField()
    is_user_online = serializers.BooleanField()
    photo_thumbnails = serializers.SerializerMethodField()

    @extend_schema_field(OpenApiTypes.OBJECT)
    def get_photo_thumbnails(self, obj):
        photo = obj.get("photo")
        if photo:
            return {
                "235х189": get_thumbnail(photo, "235x189", crop="center", quality=99).url,
                "106х106": get_thumbnail(photo, "106x106", crop="center", quality=99).url,
                "414х514": get_thumbnail(photo, "414x514", crop="center", quality=99).url,
                "45х45": get_thumbnail(photo, "45x45", crop="center", quality=99).url,
            }
        return None

    class Meta:
        fields = [
            "photo",
            "chatmate",
            "chatmate_id",
            "last_message",
            "unread_messages",
            "is_user_online",
            "photo_thumbnails",
        ]
        read_only_fields = (
            "photo",
            "chatmate",
            "chatmate_id",
            "last_message",
            "unread_messages",
            "is_user_online",
            "photo_thumbnails",
        )


class ChatResponseSerializer(serializers.Serializer):
    results = ChatSerializer(many=True)


class UnreadChatsCountSerializer(serializers.Serializer):
    unread_chats_count = serializers.IntegerField()
