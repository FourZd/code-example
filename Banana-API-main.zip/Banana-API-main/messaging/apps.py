from django.apps import AppConfig


# It's called "Messaging" and not "messages" because that label had dublicate (probably django-builtin?) and couldn't be used
class MessagingConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "messaging"
