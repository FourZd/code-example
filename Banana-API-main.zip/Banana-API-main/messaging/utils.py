from django.db.models import Count
from .models import Message


def get_unread_chats_count(recipient_id: int) -> int:
    unread_users_count: int = (
        Message.objects.filter(
            recipient_id=recipient_id, read_at=None, sender__deleted_at=None
        )  # sender__deleted_at exists because we have old messages in BD
        # which was sent by deleted users. Now we delete messages when user is deleted
        .values("sender")
        .distinct()
        .aggregate(Count("sender"))
        .get("sender__count")
    )
    return unread_users_count
