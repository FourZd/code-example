import hashlib
import os
from logging import getLogger

from django.conf import settings
from django.db.models import Q
from django.shortcuts import get_object_or_404
from django.utils import timezone
from drf_spectacular.utils import extend_schema
from rest_framework import generics, permissions, serializers, status
from rest_framework.pagination import LimitOffsetPagination
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.views import APIView

from profiles.models import Profile

from .models import Message
from .serializers import (
    ChatResponseSerializer,
    ContactsSerializer,
    MessageSerializer,
    UnreadChatsCountSerializer,
)
from .utils import get_unread_chats_count

logger = getLogger(__name__)

REDIS_CLIENT = settings.REDIS_NOTIFICATION_CLIENT
SECRET_TG_SALT = settings.SECRET_TG_SALT


class MessageCreateView(generics.CreateAPIView):
    """Used for both messages and shared contacts."""

    permission_classes = [permissions.IsAuthenticated]
    serializer_class = MessageSerializer

    def get_serializer_context(self):
        # Customize the context based on your requirements
        context = super().get_serializer_context()
        # Add any additional context data you need
        context["request"] = self.request
        return context

    def perform_create(self, serializer):
        if serializer.initial_data["type"] == "shared_contacts":
            profile = Profile.objects.get(user=self.request.user)
            if profile.telegram:
                contact_type = "telegram"
                contact_value = profile.telegram
            elif profile.whatsapp:
                contact_type = "whatsapp"
                contact_value = profile.whatsapp
            else:
                contact_value = None
                contact_type = None
            serializer.validated_data["contact_value"] = contact_value
            serializer.validated_data["contact_type"] = contact_type

        serializer.validated_data[
            "sender"
        ] = self.request.user  # TODO check if we could insert it automatically
        model = serializer.save()

        recipient_id = serializer.validated_data["recipient"].id
        if not SECRET_TG_SALT:
            raise serializers.ValidationError("SECRET_TG_SALT environment variable is not defined")
        hashed_id = hashlib.sha256((str(recipient_id) + SECRET_TG_SALT).encode()).hexdigest()
        logger.info(f"Publishing notification for user {hashed_id}")
        try:
            logger.info(f"notifications_{hashed_id}")
            REDIS_CLIENT.publish(f"notifications_{hashed_id}", "Новое сообщение")
            logger.info(f"Published notification for user {hashed_id}")
        except Exception as e:
            logger.info(f"Failed to publish notification for user {hashed_id}: {e}")
        return Response(model, status=status.HTTP_201_CREATED)


class MessageListView(generics.ListAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = MessageSerializer
    pagination_class = LimitOffsetPagination

    def get_queryset(self):
        user_id = self.request.user.id
        chatmate_id = self.kwargs.get("chatmate_id")
        if chatmate_id is not None:
            messages = Message.objects.filter_by_users(user_id, chatmate_id).order_by("-timestamp")
            return messages
        else:
            return Message.objects.none()


class ChatListAPIView(APIView):
    serializer_class = ChatResponseSerializer

    def get(self, request: Request):
        # Serializing all chats is taking too much time (around 3.5 secs for 18 chats)
        # TODO we must think of a way to optimize it, maybe we should create another DB table for chats
        # This variant is fast and doesn't seem to be dangerous
        chat_list = Message.objects.get_all_chats(request.user.id)
        return Response(chat_list, status=status.HTTP_200_OK)


class GetChatmateContactsView(APIView):
    permission_classes = [permissions.IsAuthenticated]
    lookup_field = "chatmate_id"
    serializer_class = ContactsSerializer

    def get(self, request, *args, **kwargs):
        user_id = request.user.id

        raw_data = Message.objects.get_contacts(user_id, self.kwargs["chatmate_id"])
        if raw_data:
            contacts_serializer = ContactsSerializer(data=raw_data, many=True)

            if contacts_serializer.is_valid():
                return Response(contacts_serializer.data, status=200)
            return Response(raw_data, status=400)
        else:
            return Response(status=404)


class DestroyChatAPIView(APIView):
    def get_queryset(self):
        chatmate_id = self.kwargs["chatmate_id"]  # Идентификатор собеседника
        user_id = self.request.user.id  # Идентификатор текущего пользователя

        # Получаем все сообщения между текущим пользователем и собеседником
        queryset = Message.objects.filter(
            (Q(sender=user_id) & Q(recipient=chatmate_id))
            | (Q(sender=chatmate_id) & Q(recipient=user_id))
        )
        return queryset

    def delete(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        if queryset.exists():
            queryset.update(deleted_at=timezone.now())
            return Response(status=204)
        else:
            return Response(status=404)


class ReadMessageAPIView(APIView):
    def patch(self, request, message_id):
        message = get_object_or_404(Message, id=message_id)
        if message.recipient == request.user:
            message.read_at = timezone.now()
            message.save()
            return Response(data={"status": "Message marked as read"}, status=200)
        elif message.sender == request.user:
            return Response("Can't mark your message as read", status=403)
        else:
            return Response("Message not found", status=404)


class ReadChatAPIView(APIView):
    def patch(self, request, chatmate_id):
        messages = Message.objects.filter(sender=chatmate_id, recipient=request.user, read_at=None)
        messages_len = len(messages)
        read_at = timezone.now()
        messages.update(read_at=read_at)
        return Response(
            f"Read {messages_len} messages from chat with user {chatmate_id}", status=200
        )


@extend_schema(
    responses=UnreadChatsCountSerializer,
)
class UnreadChatsCountAPIView(APIView):
    def get(self, request):
        unread_chat_count = get_unread_chats_count(request.user.id)

        response = {"unread_chats_count": unread_chat_count}
        return Response(response, status=200)


class SubscribeToNotificationsAPIView(APIView):
    def post(self, request):
        user_id = request.user.id
        if not SECRET_TG_SALT:
            raise serializers.ValidationError("SECRET_TG_SALT environment variable is not defined")
        elif not user_id:
            raise serializers.ValidationError("Please log in to use this feature")
        hashed_id = hashlib.sha256((str(user_id) + SECRET_TG_SALT).encode()).hexdigest()
        link = "https://t.me/BananaNotificationBot?start=" + hashed_id

        return Response({"link": link}, status=200)
