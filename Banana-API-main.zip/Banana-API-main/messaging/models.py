from django.db import models
from custom_auth.models import CustomUser
from django.db.models import Q
from photos.models import Photo
from profiles.models import Profile
from sorl.thumbnail import ImageField, get_thumbnail
import hashlib
from django.utils import timezone
from django.utils.crypto import get_random_string


class MessageType(models.TextChoices):
    MESSAGE = "msg"
    SHARED_CONTACTS = "shared_contacts"


class MessageManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(deleted_at__isnull=True)

    def user_messages(self, user_id):
        return self.get_queryset().filter(Q(sender=user_id) | Q(recipient=user_id))

    def get_shared_contacts_message(self, user_id, chatmate_id, check_for_both_contacts=True):
        """User_id == sender, chatmate_id == recipient"""
        messages = self.user_messages(user_id).filter(
            sender__in=(user_id, chatmate_id),
            recipient__in=(user_id, chatmate_id),
            type="shared_contacts",
        )

        if check_for_both_contacts:
            return messages if messages else None

        # Not sure if we will have to return user's shared contacts to his chatmate, so i'll keep the variant for chatmate-only shared contacts
        # shared_contacts_message = messages.filter(sender=user_id, recipient=chatmate_id).first()
        # return shared_contacts_message if shared_contacts_message else None

    def get_contacts(self, user_id, chatmate_id):
        shared_contacts_messages = self.get_shared_contacts_message(
            chatmate_id, user_id, check_for_both_contacts=True
        )
        if shared_contacts_messages:
            contacts_list = []
            for message in shared_contacts_messages:
                contacts_list.append(
                    {
                        "user": chatmate_id,
                        "contact": message.contact_value,
                        "contact_type": message.contact_type,
                    }
                )
            return contacts_list
        else:
            return None

    def filter_by_users(self, user_id, chatmate_id):
        return self.user_messages(user_id).filter(Q(sender=chatmate_id) | Q(recipient=chatmate_id))

    def get_all_chats(self, user_id):
        messages = self.user_messages(user_id)
        response = {"results": []}

        # TODO check if it could be optimised more
        raw_user_ids = messages.values_list("sender__id", "recipient__id").distinct()
        unique_ids = {id for ids in raw_user_ids for id in ids}
        unique_ids.discard(user_id)
        chat_participants = list(unique_ids)

        for participant_id in chat_participants:
            try:
                Profile.objects.get(user_id=participant_id)
            except Profile.DoesNotExist:
                continue
            participant = CustomUser.objects.get(id=participant_id)
            is_user_online = participant.is_online
            participant_messages = Message.objects.filter(
                Q(sender=participant, recipient=user_id) | Q(recipient=participant, sender=user_id)
            ).order_by("-timestamp")

            if participant_messages:
                unread_messages_count = participant_messages.filter(
                    read_at=None, sender=participant
                ).count()
                last_message = participant_messages[0]
                try:
                    chatmate_photo = Photo.objects.get(user=participant, is_primary=True)
                except Photo.DoesNotExist:
                    chatmate_photo = None
                response["results"].append(
                    {
                        "photo": chatmate_photo.photo.url if chatmate_photo else None,
                        "chatmate": participant.profile.name,
                        "chatmate_id": participant.id,
                        "last_message": {
                            "sender": last_message.sender.id,
                            "content": last_message.content,
                            "image": last_message.image.url if last_message.image else None,
                            "timestamp": str(last_message.timestamp),
                            "type": last_message.type,
                            "image_thumbnails": last_message.get_image_thumbnails(),
                        },
                        "unread_messages": unread_messages_count,
                        "is_user_online": is_user_online,
                        "photo_thumbnails": chatmate_photo.get_photo_thumbnails()
                        if chatmate_photo
                        else None,
                    }
                )
        response["results"] = sorted(
            response["results"], key=lambda chat: chat["last_message"]["timestamp"], reverse=True
        )
        return response


def upload_to(instance: "Message", filename: str) -> str:
    unique_id = get_random_string(length=32)
    tm = timezone.now()
    filename_hash = hashlib.md5(
        str(instance.sender.id).encode() + str(tm).encode() + str(unique_id).encode()
    ).hexdigest()
    file_extension = filename.split(".")[-1]
    return f"messages/{instance.sender.id}/images/{str(filename_hash)+'.'+file_extension}"


class Message(models.Model):
    sender = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name="sent_messages")
    recipient = models.ForeignKey(
        CustomUser, on_delete=models.CASCADE, related_name="received_messages"
    )
    content = models.TextField(blank=True, null=True)
    image = ImageField(blank=True, null=True, upload_to=upload_to)
    timestamp = models.DateTimeField(auto_now_add=True)
    contact_type = models.CharField(max_length=25, null=True)
    contact_value = models.CharField(max_length=100, null=True)
    type = models.CharField(max_length=25, choices=MessageType.choices)
    read_at = models.DateTimeField(null=True)
    deleted_at = models.DateTimeField(null=True)

    objects = MessageManager()

    def __str__(self):
        return f"From {self.sender.username} to {self.recipient.username}: {self.content}"

    def get_image_thumbnails(self):
        if self.image:
            return {
                "235х189": get_thumbnail(self.image, "235x189", crop="center", quality=99).url,
                "106х106": get_thumbnail(self.image, "106x106", crop="center", quality=99).url,
                "414х514": get_thumbnail(self.image, "414x514", crop="center", quality=99).url,
                "45х45": get_thumbnail(self.image, "45x45", crop="center", quality=99).url,
            }
        return None
