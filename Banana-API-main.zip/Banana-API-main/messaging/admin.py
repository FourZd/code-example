from django.contrib import admin
from .models import Message


class MessageAdmin(admin.ModelAdmin):
    list_display = ("sender", "recipient", "content", "timestamp", "type", "read_at")
    list_filter = ("sender", "recipient", "type", "read_at")
    search_fields = ("sender__username", "recipient__username", "content")
    list_per_page = 20


admin.site.register(Message, MessageAdmin)
