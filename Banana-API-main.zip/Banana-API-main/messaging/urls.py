from django.urls import path
from .views import (
    MessageCreateView,
    MessageListView,
    GetChatmateContactsView,
    ChatListAPIView,
    DestroyChatAPIView,
    ReadMessageAPIView,
    ReadChatAPIView,
    UnreadChatsCountAPIView,
    SubscribeToNotificationsAPIView,
)

urlpatterns = [
    path("send/", MessageCreateView.as_view(), name="create_message"),
    path("chat/<int:chatmate_id>/", MessageListView.as_view(), name="get_chat_messages"),
    path(
        "chat/<int:chatmate_id>/contacts/",
        GetChatmateContactsView.as_view(),
        name="get_chatmate_contacts",
    ),
    path("chats/", ChatListAPIView.as_view(), name="get_all_messages"),
    path("chat/delete/<int:chatmate_id>/", DestroyChatAPIView.as_view(), name="delete_chat"),
    path("read-message/<int:message_id>/", ReadMessageAPIView.as_view(), name="read_message"),
    path("chat/<int:chatmate_id>/read/", ReadChatAPIView.as_view(), name="read_chat"),
    path("unread-chats-count/", UnreadChatsCountAPIView.as_view(), name="unread_count"),
    path("subscribe/", SubscribeToNotificationsAPIView.as_view(), name="subscribe-to-notif"),
]
