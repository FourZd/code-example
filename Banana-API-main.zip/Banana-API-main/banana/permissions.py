# from rest_framework import permissions


# class NotDeleted(permissions.BasePermission):
#     def has_permission(self, request, view):
#         if request.user.is_deleted:
#             self.message = {"status": 422, "message": "user is deleted"}
#             return False
#         return True

# Commented for now, because we can't keep user's data after their deletion due to Apple policy.
# However, Alexander wants to implement one-click account restoration with all previous information.
# So it could be useful in the future, if we will implement it exclusively for android & web platforms
