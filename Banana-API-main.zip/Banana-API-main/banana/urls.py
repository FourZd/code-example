"""banana URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import include, path
from django.conf import settings


urlpatterns = [
    path(
        "admin/0K8g0L/RgNC+0YHRgtC+INGF0L7Rh9GDINCx0YvRgtGMINGB0YfQsNGB0YLQu9C40LLRi9C8",  # TODO transfer to git secrets
        admin.site.urls,
    ),
    path("api/auth/", include("custom_auth.urls")),
    path("api/posts/", include("posts.urls")),
    path("api/schema/", include("openapi.urls")),
    path("api/payments/", include("payments.urls")),
    path("api/cities/", include("cities.urls")),
    path("api/photos/", include("photos.urls")),
    path("api/profiles/", include("profiles.urls")),
    path("api/messages/", include("messaging.urls")),
    path("analytics/", include("analytics.urls")),
]

if settings.DEBUG:
    from django.conf.urls.static import static

    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
