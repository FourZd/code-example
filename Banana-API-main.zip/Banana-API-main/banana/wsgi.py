"""
WSGI config for banana project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/4.1/howto/deployment/wsgi/
"""

import os

from django.core.wsgi import get_wsgi_application
from gevent import monkey
from psycogreen.gevent import patch_psycopg

# Patching for gevent
monkey.patch_all()
patch_psycopg()

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "banana.settings")

application = get_wsgi_application()
