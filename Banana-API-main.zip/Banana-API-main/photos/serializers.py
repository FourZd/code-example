from drf_spectacular.types import OpenApiTypes
from drf_spectacular.utils import extend_schema_field
from rest_framework import serializers
from sorl.thumbnail import get_thumbnail
from .models import Photo


class PhotoSerializer(serializers.ModelSerializer):
    photo = serializers.ImageField()

    @extend_schema_field(OpenApiTypes.OBJECT)
    def get_thumbnails(self, obj: Photo):
        return {
            "235х189": get_thumbnail(obj.photo, "235x189", crop="center", quality=99).url,
            "106х106": get_thumbnail(obj.photo, "106x106", crop="center", quality=99).url,
            "414х514": get_thumbnail(obj.photo, "414x514", crop="center", quality=99).url,
            "45х45": get_thumbnail(obj.photo, "45x45", crop="center", quality=99).url,
        }

    thumbnails = serializers.SerializerMethodField()

    class Meta:
        model = Photo
        fields = ("id", "photo", "thumbnails", "is_primary")
        read_only_fields = (
            "id",
            "thumbnails",
        )
