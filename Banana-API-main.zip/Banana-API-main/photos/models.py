from django.conf import settings
from django.db import models
from sorl.thumbnail import ImageField, get_thumbnail
from django.utils import timezone
from django.utils.crypto import get_random_string
import hashlib


def upload_to(instance: "Photo", filename: str) -> str:
    unique_id = get_random_string(length=32)
    tm = timezone.now()
    filename_hash = hashlib.md5(
        str(instance.user.id).encode() + str(tm).encode() + str(unique_id).encode()
    ).hexdigest()
    file_extension = filename.split(".")[-1]
    return f"photos/{instance.user.id}/{str(filename_hash)+'.'+file_extension}"


class Photo(models.Model):
    id = models.AutoField(primary_key=True)
    photo = ImageField(upload_to=upload_to)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="photos"
    )
    is_primary = models.BooleanField(default=False)
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def get_photo_thumbnails(self):
        return {
            "235х189": get_thumbnail(self.photo, "235x189", crop="center", quality=99).url,
            "106х106": get_thumbnail(self.photo, "106x106", crop="center", quality=99).url,
            "414х514": get_thumbnail(self.photo, "414x514", crop="center", quality=99).url,
            "45х45": get_thumbnail(self.photo, "45x45", crop="center", quality=99).url,
        }
