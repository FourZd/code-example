from django.urls import path

from . import views

urlpatterns = [
    path("", views.PhotosListCreateView.as_view()),
    path("<int:pk>/", views.PhotosRetrieveUpdateDestroyView.as_view()),
]
