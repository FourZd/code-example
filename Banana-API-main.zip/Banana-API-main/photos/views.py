from rest_framework.generics import ListCreateAPIView, RetrieveUpdateDestroyAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.serializers import ValidationError
from .serializers import PhotoSerializer
from rest_framework.response import Response
from rest_framework import status


class PhotosListCreateView(ListCreateAPIView):
    """List and create photos"""

    serializer_class = PhotoSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return self.request.user.photos.all().order_by("-is_primary")

    def perform_create(self, serializer):
        if self.request.user.photos.count() >= 10:
            raise ValidationError("You can't upload more than 10 photos")
        if serializer.validated_data["is_primary"]:
            self.request.user.photos.update(is_primary=False)
        serializer.save(user=self.request.user)


class PhotosRetrieveUpdateDestroyView(RetrieveUpdateDestroyAPIView):
    """Retrieve, update and destroy photos. Delete method returns {"detail": "Photo deleted"}"""

    serializer_class = PhotoSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return self.request.user.photos.all()

    def perform_update(self, serializer):
        if serializer.validated_data["is_primary"]:
            self.request.user.photos.update(is_primary=False)
        serializer.save(user=self.request.user)

    def destroy(self, request, *args, **kwargs):
        super().destroy(self, request, *args, **kwargs)
        return Response({"detail": "Photo deleted"}, status=status.HTTP_200_OK)
