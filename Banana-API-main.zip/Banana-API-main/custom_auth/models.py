from django.contrib.auth.models import (
    AbstractBaseUser,
    BaseUserManager,
    PermissionsMixin,
)
from django.db import models
from datetime import timedelta
from django.utils import timezone


class GenderChoices(models.IntegerChoices):
    MALE = 0
    FEMALE = 1


class AdminUserManager(BaseUserManager):
    def get_queryset(self):
        return super().get_queryset()


class CustomUserManager(BaseUserManager):
    def create_user(self, username: str, gender: int, password=None, **extra_fields):
        if not username:
            raise ValueError("Users must have an username")

        user = self.model(username=username, gender=gender, **extra_fields)
        user.set_password(password)
        user.save()
        return user

    def create_superuser(self, username, password=None, **extra_fields):
        user = self.create_user(username, password=password, **extra_fields)
        user.is_superuser = True
        user.save()
        return user

    def get_queryset(self):
        """Exclude deleted users"""
        return super().get_queryset().filter(deleted_at__isnull=True)


class CustomUser(AbstractBaseUser, PermissionsMixin):
    username = models.CharField(max_length=100, unique=True)
    is_fake = models.BooleanField(default=False)
    last_online = models.DateTimeField(auto_now_add=True, db_index=True)
    gender = models.PositiveSmallIntegerField(choices=GenderChoices.choices)
    created_at = models.DateTimeField(auto_now_add=True)
    blocked_users = models.ManyToManyField("CustomUser", related_name="blocked_by", blank=True)
    is_superuser = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, db_index=True)

    USERNAME_FIELD = "username"
    REQUIRED_FIELDS = ["gender"]
    objects = CustomUserManager()
    admin = AdminUserManager()

    def is_male(self):
        return self.gender == GenderChoices.MALE

    def is_female(self):
        return self.gender == GenderChoices.FEMALE

    @property
    def is_staff(self):
        return self.is_superuser

    @property
    def is_online(self):
        return self.last_online > timezone.now() - timedelta(hours=5)

    def __str__(self):
        return self.username


class UserSession(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    started_at = models.DateTimeField()
    ended_at = models.DateTimeField()
