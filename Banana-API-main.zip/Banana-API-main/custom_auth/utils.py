from custom_auth.models import UserSession
from django.utils import timezone


def create_or_get_session(user):
    session, created = UserSession.objects.get_or_create(
        user=user,
        ended_at__gte=timezone.now(),
        defaults={
            "started_at": timezone.now(),
            "ended_at": timezone.now() + timezone.timedelta(minutes=10),
        },
    )
    if not created:
        session.ended_at = timezone.now() + timezone.timedelta(minutes=10)
        session.save()

    return session
