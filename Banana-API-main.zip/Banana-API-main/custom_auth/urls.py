from django.urls import include, path
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import (
    TokenBlacklistView,
    TokenObtainPairView,
    TokenRefreshView,
    TokenVerifyView,
)

from .views import (
    CurrentlyOnlineView,
    ModerationView,
    RegisterView,
    BlockAPIView,
    # SubscribeToTopicView,
)

router = DefaultRouter()

urlpatterns = [
    path("token/", TokenObtainPairView.as_view(), name="obtain_token_pair"),
    path("token/refresh/", TokenRefreshView.as_view(), name="refresh_token_pair"),
    path("token/blacklist/", TokenBlacklistView.as_view(), name="blacklist_token"),
    path("token/verify/", TokenVerifyView.as_view(), name="verify_token"),
    path("register/", RegisterView.as_view(), name="register_user"),
    path("notifications/", include(router.urls)),
    # path(
    #     "notifications/subscribe-to-topic/",
    #     SubscribeToTopicView.as_view(),
    #     name="subscribe_to_topic",
    # ),
    path(
        "users/currently-online/",
        CurrentlyOnlineView.as_view(),
        name="currently_online",
    ),
    path("moderation/", ModerationView.as_view(), name="moderation"),
    path("user-relations/block/<int:pk>/", BlockAPIView.as_view(), name="block_user"),
    # path("user-relations/unblock/<int:pk>/", UnblockAPIView.as_view(), name="unblock_user"),
    # path("user-relations/blocked/", ListOfBlockedUsersView.as_view(), name="blocked_users"),
]
