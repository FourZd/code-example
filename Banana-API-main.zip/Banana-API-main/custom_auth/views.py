import random

from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from rest_framework import status
from rest_framework.generics import CreateAPIView, ListAPIView, UpdateAPIView
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from .models import CustomUser
from .serializers import (
    CurrentlyOnlineSerializer,
    ModerationSerializer,
    UserSerializer,
    BlockUnblockUserSerializer,
    BlockedUsersSerializer,
    BlockUnblockResponseSerializer,
    # SubscribeToTopicSerializer,
)
from .mixins import BlockUnblockMixin
from drf_spectacular.utils import extend_schema, extend_schema_view
from rest_framework.pagination import LimitOffsetPagination
from payments.models import Payment, PeriodPostPayment, PeriodProfilePayment
import hashlib
from django.utils import timezone
from payments.views import PaymentStatus
from custom_auth.utils import create_or_get_session
import logging

# from .tasks import subscribe_to_topic
logger = logging.getLogger(__name__)


def gift_subscription(user, session):
    payment_id = hashlib.md5(
        str(user.id).encode("utf-8") + str(timezone.now()).encode("utf-8")
    ).hexdigest()
    payment = Payment.objects.create(
        id=payment_id,
        user=user,
        amount=0,
        currency="RUB",
        status=PaymentStatus.SUCCEEDED,
        session=session,
    )
    PeriodPostPayment.objects.create(
        period_start=timezone.now(), period_end=timezone.datetime(2024, 1, 31), payment=payment
    )
    PeriodProfilePayment.objects.create(
        period_start=timezone.now(), period_end=timezone.datetime(2024, 1, 31), payment=payment
    )
    logger.info("Subscription gift created")


class RegisterView(CreateAPIView):
    """Register a new user."""

    model = CustomUser
    serializer_class = UserSerializer
    pagination_class = LimitOffsetPagination

    def perform_create(self, serializer):
        serializer.validated_data["is_fake"] = self.request.is_on_moderation
        user = serializer.save()
        logger.info("Gift subscription")
        logger.info(f"User {user}")
        session = create_or_get_session(user)

        gift_subscription(user, session)
        return user


class CurrentlyOnlineView(APIView):
    """Returns a number of currently online users."""

    serializer_class = CurrentlyOnlineSerializer

    @method_decorator(cache_page(60 * 15))
    def get(self, request):
        """Return a number of currently online users."""
        return Response({"online": get_online_now()})


def get_online_now():
    """Return a number of currently online users."""
    return random.choice(range(1000, 2000))


class ModerationView(APIView):
    """Returns a flag, whether the app is on moderation."""

    serializer_class = ModerationSerializer

    def get(self, request):
        return Response({"is_on_moderation": request.is_on_moderation})


@extend_schema_view(post=extend_schema(responses=BlockUnblockResponseSerializer))
class BlockAPIView(APIView, BlockUnblockMixin):
    def post(self, request, *args, **kwargs):
        action_user_id = kwargs.get("pk")
        validated_data = self.handle_action(request, "block", action_user_id)
        return Response(
            validated_data,
            status=status.HTTP_200_OK,
        )


# class SubscribeToTopicView(APIView):
#     serializer_class = SubscribeToTopicSerializer

#     def post(self, request, *args, **kwargs):
#         serializer = SubscribeToTopicSerializer(data=request.data)
#         serializer.is_valid(raise_exception=True)

#         subscribe_to_topic.delay(request.user.id, serializer.validated_data["auth_token"])
#         return Response(status=status.HTTP_200_OK)


# LIST OF BLOCKS & UNBLOCK ENDPOINTS
# // Currently not required, uncomment if needed

# class ListOfBlockedUsersView(ListAPIView):
#     permission_classes = [IsAuthenticated]
#     serializer_class = BlockedUsersSerializer

#     def list(self, request, *args, **kwargs):
#         serializer = self.get_serializer(request.user)
#         return Response(serializer.data)


# class UnblockAPIView(APIView, BlockUnblockMixin):
#     def delete(self, request, *args, **kwargs):
#         action_user_id = kwargs.get('pk')
#         validated_data = self.handle_action(request, "unblock", action_user_id)
#         return Response(
#             validated_data,
#             status=status.HTTP_200_OK,
#         )
