from celery import shared_task
from django.utils import timezone
from rest_framework_simplejwt.token_blacklist.models import OutstandingToken


@shared_task
def flush_tokens():
    OutstandingToken.objects.filter(expires_at__lte=timezone.now()).delete()


# @shared_task()
# def subscribe_to_topic(user_id, auth_token):
#     messaging.subscribe_to_topic(tokens=[auth_token], topic=f"/topics/messages/{user_id}")
