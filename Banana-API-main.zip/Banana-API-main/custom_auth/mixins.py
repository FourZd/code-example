from .serializers import BlockUnblockUserSerializer
from rest_framework.permissions import IsAuthenticated
from .models import CustomUser


# TODO Refactor
class BlockUnblockMixin:
    permission_classes = [IsAuthenticated]

    def handle_action(self, request, action, action_user_id):
        user = CustomUser.objects.get(id=request.user.id)
        serializer = BlockUnblockUserSerializer(
            data={"action_user_id": action_user_id}, context={"request": request}
        )
        if serializer.is_valid(raise_exception=True):
            validated_data = serializer.validated_data
            action_user_id = validated_data["action_user_id"]
            if action == "block":
                user.blocked_users.add(action_user_id)
            elif action == "unblock":
                user.blocked_users.remove(action_user_id)
            return {
                "status": "ok",
                "action": action,
                "action_user_id": action_user_id,
                "message": "Operation is successful",
            }
