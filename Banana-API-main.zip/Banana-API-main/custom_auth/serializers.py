from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django.contrib.auth.password_validation import (
    validate_password,
)
from .models import CustomUser
import re


class PublicUserSerializer(serializers.ModelSerializer):
    """We don't want to show is_fake & last_online fields to public"""

    class Meta:
        model = CustomUser
        fields = ("id", "username", "gender")
        read_only_fields = ("id", "username", "gender")


class UserSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)

    class Meta:
        model = CustomUser
        fields = ("id", "username", "gender", "is_fake", "last_online", "password")
        read_only_fields = ("id", "is_fake", "last_online")

    def create(self, validated_data):
        return CustomUser.objects.create_user(**validated_data)

    def _validate_username(self, username) -> None:
        pattern = r"^[a-zA-Z0-9\.\-_]*$"
        errors = []
        if len(username) < 4:
            errors.append("Username must be at least 4 characters")
        if len(username) > 20:
            errors.append("Username must be at most 20 characters")
        if not re.match(pattern, username):
            errors.append("Username must contain only latin letters and .-_ symbols")
        if " " in username:
            errors.append("Username cannot contain spaces")

        if errors:
            raise serializers.ValidationError({"username_errors": errors})

    def validate(self, attrs):
        password = attrs.get("password")
        validate_password(password)
        username = attrs.get("username")
        self._validate_username(username)

        return super().validate(attrs)


class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)

        data = UserSerializer(user).data
        for key, value in data.items():
            token[key] = value

        return token


class CurrentlyOnlineSerializer(serializers.Serializer):
    online = serializers.IntegerField()


class ModerationSerializer(serializers.Serializer):
    is_on_moderation = serializers.BooleanField()


class BlockUnblockUserSerializer(serializers.Serializer):
    action_user_id = serializers.IntegerField()

    def validate(self, attrs):
        action_user = attrs.get("action_user_id")
        user_id = self.context["request"].user.id

        if not CustomUser.objects.filter(id=action_user).exists():
            raise serializers.ValidationError("User is not found")

        elif user_id == action_user:
            raise serializers.ValidationError("You can't block yourself")

        return super().validate(attrs)


class BlockedUsersSerializer(serializers.ModelSerializer):
    """Currently unused serializer for list of blocked users"""

    blocked_users = PublicUserSerializer(many=True)

    class Meta:
        model = CustomUser
        fields = ("blocked_users",)


class BlockUnblockResponseSerializer(serializers.Serializer):
    status = serializers.CharField()
    action = serializers.CharField()
    action_user_id = serializers.IntegerField()
    message = serializers.CharField()


# class SubscribeToTopicSerializer(serializers.Serializer):
#     auth_token = serializers.CharField()
