from rest_framework import permissions


class IsMaleOrReadOnly(permissions.IsAuthenticated):
    message = "Creating posts is not allowed"

    def has_permission(self, request, view):
        if not super().has_permission(request, view):
            return False
        if request.method in permissions.SAFE_METHODS:
            return True
        return request.user.is_male()
