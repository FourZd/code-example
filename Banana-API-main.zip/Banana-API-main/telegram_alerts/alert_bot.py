import asyncio
import logging
import os
import sys

import redis.asyncio as redis
from aiogram import Bot, Dispatcher, types
from aiogram.filters.command import Command
from aiogram.fsm.storage.memory import MemoryStorage

TG_NOTIFICATIONS_REDIS_URL = os.getenv(
    "TG_NOTIFICATIONS_REDIS_URL", "redis://127.0.0.1:6379/3"
)
bot = Bot(token="6943840154:AAGwrfSctxpoB_8lLE6hvfvwWFFZA7R0DMU")
storage = MemoryStorage()
dp = Dispatcher(storage=storage)
redis_client = redis.Redis.from_url(TG_NOTIFICATIONS_REDIS_URL)
tasks = {}


async def listen_for_payments():
    pubsub = redis_client.pubsub()
    await pubsub.subscribe("payments")
    async for message in pubsub.listen():
        if message["type"] == "message":
            logging.info(f"Received payment: {message}")
            await bot.send_message(chat_id=-4070266600, text=message["data"])


async def listen_for_user_notifications(user_id, chat_id):
    logging.info(f"Initializing listener for user {user_id}")
    pubsub = redis_client.pubsub()
    logging.info(f"Subscribing to channel notifications_{user_id}")
    await pubsub.subscribe(f"notifications_{user_id}")
    logging.info(f"Listening for notifications for user {user_id}")
    async for message in pubsub.listen():
        logging.info(f"Received message: {message}")
        if message["type"] == "message":
            logging.info(f"Received notification for user {user_id}")
            await bot.send_message(chat_id, "У вас новое сообщение!")
            logging.info(f"Sent notification to user {user_id}")


async def resubscribe_to_channels():
    logging.info("Resubscribing to channels")
    keys = await redis_client.keys("chatid_*")
    for key in keys:
        user_id = key.decode("utf-8").split("_")[1]
        chat_id = await redis_client.get(key)
        if chat_id:
            task = asyncio.create_task(
                listen_for_user_notifications(user_id, chat_id.decode("utf-8"))
            )
            tasks[user_id] = task


async def remove_previous_user_if_exists(user_id, chat_id):
    logging.info(f"Removing previous user for chat_id {chat_id}")
    existing_user_id = await redis_client.get(f"userid_{chat_id}")
    if existing_user_id:
        logging.info(f"Found existing user {existing_user_id} for chat_id {chat_id}")
        existing_user_id = existing_user_id.decode("utf-8")
        logging.info(f"Removing previous user {existing_user_id} for chat_id {chat_id}")
        if existing_user_id != user_id:
            await redis_client.delete(f"chatid_{existing_user_id}")
            task = tasks.get(existing_user_id)
            if task:
                task.cancel()
                del tasks[existing_user_id]
            logging.info(
                f"Removed previous user {existing_user_id} for chat_id {chat_id}"
            )


async def main():
    try:
        response = await redis_client.ping()
        if response:
            logging.info("Connection to Redis server successful!")
        else:
            logging.error("Failed to connect to Redis server.")
    except redis.ConnectionError:
        logging.error("Error: Failed to connect to Redis server.")
    try:
        await resubscribe_to_channels()
        asyncio.create_task(listen_for_payments())
        await dp.start_polling(bot)
    except Exception as e:
        logging.error(f"Error during bot polling: {e}")


@dp.message(Command("start"))
async def start_handler(message: types.Message):
    logging.info("Received start command")
    args = message.text.split(maxsplit=1) if message.text else []
    if len(args) > 1:
        user_id = args[1]
        chat_id = message.from_user.id
        await remove_previous_user_if_exists(user_id, chat_id)
        logging.info(f"Received user_id {user_id} and chat_id {chat_id}")
        await redis_client.set(f"chatid_{user_id}", chat_id)
        await redis_client.set(f"userid_{chat_id}", user_id)
        logging.info(f"Set chat_id {chat_id} for user {user_id}")
        logging.info(f"Subscribing user {user_id} to notifications")
        if user_id in tasks:
            tasks[user_id].cancel()
        task = asyncio.create_task(listen_for_user_notifications(user_id, chat_id))
        tasks[user_id] = task
        logging.info(f"Subscribed user {user_id} to notifications")
        await message.reply("Вы подписались на уведомления!")
    else:
        await message.reply(
            "Привет! Пожалуйста, используйте ссылку на сайте для подключения уведомлений."
        )


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, stream=sys.stdout)
    asyncio.run(main())
