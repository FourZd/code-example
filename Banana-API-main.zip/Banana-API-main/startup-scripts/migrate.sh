#!/bin/bash
python manage.py migrate --noinput