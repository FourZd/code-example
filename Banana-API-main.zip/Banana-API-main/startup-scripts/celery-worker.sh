#!/bin/bash
echo $GOOGLE_CREDENTIALS > /app/google-credentials.json;

echo "Starting Celery Worker.";

celery -A banana worker -l info
