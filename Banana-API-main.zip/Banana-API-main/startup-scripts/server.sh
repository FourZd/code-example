#!/bin/bash
echo $GOOGLE_CREDENTIALS > /app/google-credentials.json;

echo "Starting Gunicorn on port $PORT.";

/usr/local/bin/gunicorn banana.wsgi:application --bind 0.0.0.0:$PORT --workers $WORKERS --worker-class=gevent --worker-connections 1000\
     --certfile=/app/deploy/tls_cert.pem --keyfile=/app/deploy/tls_key.pem --reload
