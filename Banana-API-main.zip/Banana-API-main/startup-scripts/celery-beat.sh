#!/bin/bash
echo $GOOGLE_CREDENTIALS > /app/google-credentials.json;

echo "Starting Celery Beat.";

celery -A banana beat -l info